package bachelor_degree.utils.convertors;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.StudentDTO;
import bachelor_degree.model.persistence.Student;

@Component
public class StudentConvertor {
	public static Student convertStudentDTO(StudentDTO studentDTO){
		Student student = new Student();
		student.setFirstName(studentDTO.getName());
		student.setLastName(studentDTO.getSurname());
		student.setEmail(studentDTO.getEmail());
		student.setPassword(studentDTO.getPassword());
		return student;
	}
}
