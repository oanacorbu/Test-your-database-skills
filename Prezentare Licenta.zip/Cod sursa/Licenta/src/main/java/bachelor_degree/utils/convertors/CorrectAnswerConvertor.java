package bachelor_degree.utils.convertors;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.CorrectAnswerDTO;
import bachelor_degree.model.persistence.CorrectAnswer;

@Component
public class CorrectAnswerConvertor {

	public static List<CorrectAnswerDTO> convertCorrectAnswerToDTO(List<CorrectAnswer> correctAnswers ){
		List<CorrectAnswerDTO> correctAnswersDTO = new ArrayList<>();
		
		for (CorrectAnswer correctAnswer : correctAnswers){
			CorrectAnswerDTO correctAnswerDTO = new CorrectAnswerDTO();
			correctAnswerDTO.setAnswer(AnswerConvertor.convertOneAnswerToDTO(correctAnswer.getAnswer()));
			correctAnswersDTO.add(correctAnswerDTO);
		}
		
		return correctAnswersDTO;
	} 
	
	public static CorrectAnswerDTO convertOneCorrectAnswerToDTO(CorrectAnswer correctAnswer ){
		CorrectAnswerDTO correctAnswerDTO = new CorrectAnswerDTO();
		correctAnswerDTO.setAnswer(AnswerConvertor.convertOneAnswerToDTO(correctAnswer.getAnswer()));
			
		return correctAnswerDTO;
	} 
}
