package bachelor_degree.utils.convertors;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.CategoryDTO;
import bachelor_degree.model.persistence.Category;

@Component
public class CategoryConvertor {
	
	public static List<CategoryDTO> convertCategoryToDTO(List<Category> categories){
		List<CategoryDTO> categoriesDTO = new ArrayList<>();
		
		for ( Category category : categories){
			CategoryDTO categoryDTO = new CategoryDTO();
			categoryDTO.setCategoryName(category.getCategoryName());
			categoryDTO.setCategoryLevel(CategoryLevelConvertor.convertCategoryLevelToDTO(category.getLevels()));
			
			categoriesDTO.add(categoryDTO);
		}
		
		return categoriesDTO;
	}
}
