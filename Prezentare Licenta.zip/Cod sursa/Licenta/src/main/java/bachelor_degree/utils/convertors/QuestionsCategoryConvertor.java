package bachelor_degree.utils.convertors;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.QuestionsCategoryDTO;
import bachelor_degree.model.persistence.QuestionsCategory;

@Component
public class QuestionsCategoryConvertor {

	public static QuestionsCategoryDTO convertQuestionToDTO(QuestionsCategory situation){
		QuestionsCategoryDTO questionsCategoryDTO = new QuestionsCategoryDTO();
		questionsCategoryDTO.setId(situation.getId());
		questionsCategoryDTO.setCategoryName(situation.getCategoryName());
		questionsCategoryDTO.setNrOfDifficult(situation.getNrOfDifficult());
		questionsCategoryDTO.setNrOfMedium(situation.getNrOfMedium());
		questionsCategoryDTO.setNrOfSimple(situation.getNrOfSimple());
		
		return questionsCategoryDTO;
	}
}
