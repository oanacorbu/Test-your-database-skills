package bachelor_degree.utils.configuration;

public class UrlMappings {
	public static final String DEFAULT_PAGE = "/";
	public static final String EMPTY_STRING = "";
	public static final String REDIRECT = "redirect:";
	public static final String HOME = "/home";
    public static final String LOGIN = "/login";
    public static final String LOGOUT = "/logout";
    public static final String REGISTER = "/register";
    public static final String REGISTER_NEW_STUDENT = "/registerNewStudent";
    public static final String RETRIEVE_CATEGORIES_DATA = "/retrieveCategoriesData";
    public static final String SAVE_TEST_RESULTS_OF_ONE_STUDENT = "/saveResults";
    public static final String SHOW_ALL_TEST_RESULTS = "/showAllTestResults";
    public static final String RETRIEVE_QUESTION_ANSWERS = "/retrieveQuestionAnswers";
    public static final String RETRIEVE_QUESTION_CORRECT_ANSWER = "/retrieveQuestionCorrectAnswer";
    public static final String GET_ALL_PROFESSORS_LIST = "/getAllProfessorsList";
    public static final String SEND_EMAIL_WITH_TEST_RESULTS = "/sendEmailWithTestResults";
}
