package bachelor_degree.utils.convertors;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.QuestionDTO;
import bachelor_degree.model.persistence.Question;

@Component
public class QuestionConvertor {
	
	public static List<QuestionDTO> convertQuestionToDTO(List<Question> questions){
		List<QuestionDTO> questionsDTO = new ArrayList<>();
		
		for (Question question : questions){
			QuestionDTO questionDTO = new QuestionDTO();
			questionDTO.setId(question.getId());
			questionDTO.setName(question.getName());
			questionDTO.setLevelPosition(question.getLevelPosition());
			questionDTO.setDifficulty(question.getDifficulty());
			questionDTO.setDescription(question.getDescription());
			questionDTO.setScore(question.getScore());
			questionDTO.setAnswers(AnswerConvertor.convertAnswerToDTO(question.getAnswers()));
			questionDTO.setCorrectAnswer(CorrectAnswerConvertor.convertOneCorrectAnswerToDTO(question.getCorrectAnswer()));
			questionDTO.setImage_relative_path(question.getImage_relative_path());
			
			questionsDTO.add(questionDTO);
		}
		return questionsDTO;
	}
}
