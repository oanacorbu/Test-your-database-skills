package bachelor_degree.utils.convertors;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.ClassificationDTO;
import bachelor_degree.model.persistence.Classification;

@Component
public class ClassificationConvertor {

	public static List<ClassificationDTO> convertClassificationToDTO(List<Classification> classifications){
		List<ClassificationDTO> classificationsDTOs = new ArrayList<>();
		
		for (Classification classification : classifications){
			ClassificationDTO classificationDTO = new ClassificationDTO();
			classificationDTO.setId(classification.getId());
			classificationDTO.setFirstName(classification.getFirstName());
			classificationDTO.setLastName(classification.getLastName());
			classificationDTO.setEmail(classification.getEmail());
			classificationDTO.setCategoryname(classification.getCategoryname());
			classificationDTO.setObtainedScore(classification.getObtainedScore());
			classificationDTO.setSolvedDifficultQuestions(classification.getSolvedDifficultQuestions());
			classificationDTO.setSolvedMediumQuestions(classification.getSolvedMediumQuestions());
			classificationDTO.setSolvedSimpleQuestions(classification.getSolvedSimpleQuestions());
			
			classificationsDTOs.add(classificationDTO);
		}
		return classificationsDTOs;
	}
	
	public static Classification convertClassificationDTOToEntity(ClassificationDTO classificationDTO){
		Classification classification = new Classification();
		
		classification.setId(classificationDTO.getId());
		classification.setFirstName(classificationDTO.getFirstName());
		classification.setLastName(classificationDTO.getLastName());
		classification.setEmail(classificationDTO.getEmail());
		classification.setCategoryname(classificationDTO.getCategoryname());
		classification.setObtainedScore(classificationDTO.getObtainedScore());
		classification.setSolvedDifficultQuestions(classificationDTO.getSolvedDifficultQuestions());
		classification.setSolvedMediumQuestions(classificationDTO.getSolvedMediumQuestions());
		classification.setSolvedSimpleQuestions(classificationDTO.getSolvedSimpleQuestions());
		
		return classification;
	}
}
