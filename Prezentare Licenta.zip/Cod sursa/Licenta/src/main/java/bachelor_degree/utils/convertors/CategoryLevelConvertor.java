package bachelor_degree.utils.convertors;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.CategoryLevelDTO;
import bachelor_degree.model.persistence.CategoryLevel;

@Component
public class CategoryLevelConvertor {

	
	public static List<CategoryLevelDTO> convertCategoryLevelToDTO(List<CategoryLevel> categoryLevels){
		List<CategoryLevelDTO> categoryLevelsDTO = new ArrayList<>();
		
		for (CategoryLevel categoryLevel : categoryLevels){
			CategoryLevelDTO categoryLevelDTO = new CategoryLevelDTO();
			categoryLevelDTO.setLevelNumber(categoryLevel.getLevelNumber());
			categoryLevelDTO.setQuestionsDTO(QuestionConvertor.convertQuestionToDTO(categoryLevel.getQuestions()));
			
			categoryLevelsDTO.add(categoryLevelDTO);
		}
		
		return categoryLevelsDTO;
	} 
} 
