package bachelor_degree.utils.configuration;

public class FileSystemMappings {
	public static final String LOGIN = "common/loginPage";
	public static final String HOME = "common/homePage";
	public static final String REGISTER = "common/registerPage";
}
