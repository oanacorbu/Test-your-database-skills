package bachelor_degree.utils.convertors;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import bachelor_degree.DTO.AnswerDTO;
import bachelor_degree.model.persistence.Answer;

@Component
public class AnswerConvertor {

	public static List<AnswerDTO> convertAnswerToDTO(List<Answer> answers) {
		List<AnswerDTO> answersDTO = new ArrayList<>();

		for (Answer answer : answers) {
			AnswerDTO answerDTO = new AnswerDTO();
			answerDTO.setName(answer.getName());
			answerDTO.setId(answer.getId());
			answersDTO.add(answerDTO);
		}

		return answersDTO;
	}
	
	public static AnswerDTO convertOneAnswerToDTO(Answer answer) {
		AnswerDTO answerDTO = new AnswerDTO();
		answerDTO.setName(answer.getName());
		answerDTO.setId(answer.getId());
		return answerDTO;
	}
}
