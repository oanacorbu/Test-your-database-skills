package bachelor_degree.authentication;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;

import bachelor_degree.model.persistence.Student;
import bachelor_degree.services.StudentService;

public class CustomAuthenticationServiceProvider implements AuthenticationProvider{

	@Autowired 
	private StudentService studentService;
	
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		
		String studentEmail = authentication.getName();
		String password = authentication.getCredentials().toString();
		
		Student authenticatedStudent;
		if ((authenticatedStudent = studentService.getStudentByEmail
				(studentEmail)) == null ){
			throw new AuthenticationCredentialsNotFoundException("Email not found");
		}
		
		if ((authenticatedStudent = studentService.getStudentByEmailAndPassword(
				studentEmail, password)) == null){
			throw new AuthenticationCredentialsNotFoundException("Wrong credentials");
		}
		
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		return new UsernamePasswordAuthenticationToken(authenticatedStudent,
				null,grantedAuthorities);
	}

	@Override
	public boolean supports(Class<? extends Object> authentication) {
		return UsernamePasswordAuthenticationToken.class.equals(authentication);
	}
}
