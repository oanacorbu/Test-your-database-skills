package bachelor_degree.model.DAO;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.QuestionsCategory;

@Repository
public class QuestionsCategoryDAO extends AbstractDAO<QuestionsCategory>{

	public QuestionsCategoryDAO(){
		super(QuestionsCategory.class);
	}
}
