package bachelor_degree.model.DAO;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.Student;

@Repository
public class StudentDAO extends AbstractDAO<Student>{

	public StudentDAO(){
		super(Student.class);
	}
	
	public List<Student> getStudentByNameAndSurname(
			String firstName, String lastName){
		List<Student> students = null;
		
		try{
		   students = this.getEntityManager()
				   .createNamedQuery(Student.GET_STUDENTS_BY_NAME_AND_SURNAME,Student.class)
				   .setParameter("name", firstName)
				   .setParameter("surname", lastName)
				   .getResultList();
		}catch(Exception e){
			e.printStackTrace();
		}
		return students;
	}
	
	public Student getStudentByEmail(String email){
		Student student = null;
		
		try{
		   student = this.getEntityManager()
				   .createNamedQuery(Student.GET_STUDENTS_BY_EMAIL,Student.class)
				   .setParameter("email", email)
				   .getSingleResult();
		}catch(NoResultException e){
			System.out.println("nu e nici un student");
		}catch(Exception e){
			e.printStackTrace();
		}
		return student;
	}
	
	public Student getStudentByEmailAndPassword(String email,String password){
		Student student = null;
		try{
			  student = this.getEntityManager()
					   .createNamedQuery(Student.GET_STUDENT_BY_EMAIL_AND_PASSWORD,Student.class)
					   .setParameter("email", email)
					   .setParameter("password", password)
					   .getSingleResult();
		}catch(NoResultException e) {
            e.printStackTrace();
        }catch(Exception e){
			e.printStackTrace();
		}
		
		return student;
	} 
}
