package bachelor_degree.model.persistence;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.codehaus.jackson.annotate.JsonManagedReference;

@NamedQueries({
	@NamedQuery(name = Category.GET_ALL_CATEGORIES,
			query = "select c FROM Category c ")
})
@Entity
@Table(name = "categories")
public class Category implements Serializable{

	private static final long serialVersionUID = -179864899759408704L;
	public static final String GET_ALL_CATEGORIES = "getAllCategories";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "categories_id_seq", sequenceName = "categories_id_seq", allocationSize = 1)
    private Long id;
	
	@NotNull
	@Column(name = "category_name")
	private String categoryName;
	
	@NotNull
	@JsonManagedReference
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "category", cascade = CascadeType.ALL)
	private List<CategoryLevel> levels; 
	
	public Category(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<CategoryLevel> getLevels() {
		return levels;
	}

	public void setLevels(List<CategoryLevel> levels) {
		this.levels = levels;
	}
}
