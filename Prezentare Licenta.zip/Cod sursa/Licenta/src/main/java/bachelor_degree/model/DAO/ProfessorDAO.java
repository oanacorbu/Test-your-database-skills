package bachelor_degree.model.DAO;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.Professor;

@Repository
public class ProfessorDAO extends AbstractDAO<Professor>{

	public ProfessorDAO(){
		super(Professor.class);
	}
	
	public List<String> getProfessorsMailList(){
		TypedQuery<String> query = this.getEntityManager()
				  .createQuery("SELECT p.email FROM Professor p", String.class);
		List<String> professorMailList = query.getResultList();
		return professorMailList;
	}
}
