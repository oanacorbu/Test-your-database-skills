package bachelor_degree.model.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@NamedQueries({
	@NamedQuery(name = Classification.GET_ALL_TEST_RESULTS,
			query = "select c FROM Classification c ")
})
@Entity
@Table(name = "classifications")
public class Classification implements Serializable{

	private static final long serialVersionUID = -356341755248728753L;
    public static final String GET_ALL_TEST_RESULTS = "getAllTestResults";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "classifications_id_seq", sequenceName = "classifications_id_seq", allocationSize = 1)
    private Long id;
	
	@NotNull
	@Column(name = "student_name")
	private String firstName;
	
	@NotNull
	@Column(name = "student_surname")
	private String lastName;
	
	@NotNull
	@Column(name = "student_email")
	private String email;
	
	@NotNull
	@Column(name = "category")
	private String categoryname;
	
	@NotNull
	@Column(name = "obtained_score")
	private Long obtainedScore;
	
	@NotNull
	@Column(name = "solved_difficult_questions")
	private Long solvedDifficultQuestions;
	
	@NotNull
	@Column(name = "solved_medium_questions")
	private Long solvedMediumQuestions;
	
	@NotNull
	@Column(name = "solved_simple_questions")
	private Long solvedSimpleQuestions;
	
	public Classification(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public Long getObtainedScore() {
		return obtainedScore;
	}

	public void setObtainedScore(Long obtainedScore) {
		this.obtainedScore = obtainedScore;
	}

	public Long getSolvedDifficultQuestions() {
		return solvedDifficultQuestions;
	}

	public void setSolvedDifficultQuestions(Long solvedDifficultQuestions) {
		this.solvedDifficultQuestions = solvedDifficultQuestions;
	}

	public Long getSolvedMediumQuestions() {
		return solvedMediumQuestions;
	}

	public void setSolvedMediumQuestions(Long solvedMediumQuestions) {
		this.solvedMediumQuestions = solvedMediumQuestions;
	}

	public Long getSolvedSimpleQuestions() {
		return solvedSimpleQuestions;
	}

	public void setSolvedSimpleQuestions(Long solvedSimpleQuestions) {
		this.solvedSimpleQuestions = solvedSimpleQuestions;
	}
}
