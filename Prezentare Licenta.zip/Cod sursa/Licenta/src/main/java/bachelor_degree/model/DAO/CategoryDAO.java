package bachelor_degree.model.DAO;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.Category;

@Repository
public class CategoryDAO extends AbstractDAO<Category>{

	public CategoryDAO(){
		super(Category.class);
	}
	
	public List<Category> getGraphCategories(){
		List<Category> categories = null;
		
		try{
			categories = this.getEntityManager()
					.createNamedQuery(Category.GET_ALL_CATEGORIES,Category.class)
					.getResultList();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return categories;
	}
}
