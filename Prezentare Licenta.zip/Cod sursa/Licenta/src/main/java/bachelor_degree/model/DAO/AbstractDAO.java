package bachelor_degree.model.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@EnableTransactionManagement
public abstract class AbstractDAO<T> {

	@PersistenceContext
	private EntityManager em;

	private final Class<T> entityClass;

	protected AbstractDAO(final Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	public EntityManager getEntityManager() {
		return em;
	}

	@Transactional
	public void save(T entityToBeSaved) {
		this.em.persist(entityToBeSaved);
	}

	@Transactional
	public void update(T entityToBeUpdated) {
		this.em.merge(entityToBeUpdated);
	}

	@Transactional
	public void delete(T entityToBeDeleted) {
		this.em.remove(entityToBeDeleted);
	}

	@Transactional
	public T findById(Long id) {
		T entityFound = this.em.find(entityClass, id);
		return entityFound;
	}

	@Transactional
	public void deleteById(Long id) {
		this.em.remove(findById(id));
	}
}
