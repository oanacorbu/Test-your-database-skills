package bachelor_degree.model.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.Classification;

@Repository
public class ClassificationDAO extends AbstractDAO<Classification>{

	public ClassificationDAO(){
		super(Classification.class);
	}
	
	public List<Classification> getAllClassifications(){
		List<Classification> classifications = null;
		
		try{ 
			classifications = this.getEntityManager()
				   .createNamedQuery(Classification.GET_ALL_TEST_RESULTS,Classification.class)
				   .getResultList();
		}catch(Exception e){
			e.printStackTrace();
		}
		return classifications;
	}
}
