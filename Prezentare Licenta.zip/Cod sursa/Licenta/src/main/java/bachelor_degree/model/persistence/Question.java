package bachelor_degree.model.persistence;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.codehaus.jackson.annotate.JsonBackReference;

@NamedQueries({
//	@NamedQuery(name = Question.GET_ANSWERS_ORDERED_BY_ID, query = "select q from Question q "
//			+ ""),
})
@Entity
@Table(name = "questions")
public class Question implements Serializable{

	private static final long serialVersionUID = -4989234553848230499L;
	public static final String GET_ANSWERS_ORDERED_BY_ID = "getAnswersOrderedById";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "questions_id_seq", sequenceName = "questions_id_seq", allocationSize = 1)
    private Long id;
	
	@NotNull
	@Column(name = "name")
	private String name;
	
	@Column(name = "image_path")
	private String image_relative_path;
	
	@NotNull
	@Column(name = "short_description")
	private String description;

	@NotNull
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_level")
	private CategoryLevel categoryLevel;
	
	@NotNull
	@Column(name = "level_position")
	private Integer levelPosition;
	
	@NotNull
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "question")
	private List<Answer> answers;
	
	@NotNull
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "question")
	private CorrectAnswer correctAnswer;
	
	@NotNull
	@Column(name = "difficulty")
	private String difficulty;
	
	@NotNull
	@Column(name = "score")
	private Integer score;
	
	public Question(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public String getImage_relative_path() {
		return image_relative_path;
	}

	public void setImage_relative_path(String image_relative_path) {
		this.image_relative_path = image_relative_path;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	
	public CorrectAnswer getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswers(CorrectAnswer correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public Integer getLevelPosition() {
		return levelPosition;
	}

	public void setLevelPosition(Integer levelPosition) {
		this.levelPosition = levelPosition;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public CategoryLevel getCategoryLevel() {
		return categoryLevel;
	}

	public void setCategoryLevel(CategoryLevel categoryLevel) {
		this.categoryLevel = categoryLevel;
	}
}
