package bachelor_degree.model.persistence;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "questions_categories")
public class QuestionsCategory implements Serializable{

	private static final long serialVersionUID = 7529144494033624792L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "questions_categories", sequenceName = "questions_categories_id_seq", allocationSize = 1)
    private Long id;
	
	@NotNull
	@Column(name = "category_name")
	private String categoryName;
	
	@NotNull
	@Column(name = "nr_difficult")
	private Long nrOfDifficult;
	
	@NotNull
	@Column(name = "nr_medium")
	private Long nrOfMedium;
	
	@NotNull
	@Column(name = "nr_simple")
	private Long nrOfSimple;
	
	public QuestionsCategory(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Long getNrOfDifficult() {
		return nrOfDifficult;
	}

	public void setNrOfDifficult(Long nrOfDifficult) {
		this.nrOfDifficult = nrOfDifficult;
	}

	public Long getNrOfMedium() {
		return nrOfMedium;
	}

	public void setNrOfMedium(Long nrOfMedium) {
		this.nrOfMedium = nrOfMedium;
	}

	public Long getNrOfSimple() {
		return nrOfSimple;
	}

	public void setNrOfSimple(Long nrOfSimple) {
		this.nrOfSimple = nrOfSimple;
	}
}
