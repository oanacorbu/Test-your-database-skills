package bachelor_degree.model.persistence;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.codehaus.jackson.annotate.JsonManagedReference;


@Entity
@Table(name = "categories_levels")
public class CategoryLevel implements Serializable{

	private static final long serialVersionUID = 1714636219970260782L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name = "categories_levels_id_seq", sequenceName = "categories_levels_id_seq", allocationSize = 1)
    private Long id;
	
	@NotNull
	@Column(name = "level_number")
	private Long levelNumber;
	
	@NotNull
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id")
	private Category category;
	
	@NotNull
	@JsonManagedReference
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "categoryLevel", cascade = CascadeType.ALL)
	private List<Question> questions;
	
	public CategoryLevel(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLevelNumber() {
		return levelNumber;
	}

	public void setLevelNumber(Long levelNumber) {
		this.levelNumber = levelNumber;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
}
