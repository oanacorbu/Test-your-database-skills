package bachelor_degree.model.DAO;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.Answer;

@Repository
public class AnswerDAO extends AbstractDAO<Answer>{

	public AnswerDAO(){
		super(Answer.class);
	}

	public List<Answer> getAnswersOrderedById(Long questionId){
		 TypedQuery<Answer> query = this.getEntityManager()
				 						.createQuery(
				 						"SELECT a FROM Answer a WHERE a.question.id = :id "
				 						+ "ORDER BY a.id", Answer.class);
		 List<Answer> answers =  query.setParameter("id", questionId).getResultList();
		 return answers;
	}
}
