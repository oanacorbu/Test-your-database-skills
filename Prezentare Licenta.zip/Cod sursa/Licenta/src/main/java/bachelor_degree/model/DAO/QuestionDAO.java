package bachelor_degree.model.DAO;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import bachelor_degree.model.persistence.Answer;
import bachelor_degree.model.persistence.Question;

@Repository
public class QuestionDAO extends AbstractDAO<Question>{

	public QuestionDAO(){
		super(Question.class);
	}
	
}
