package bachelor_degree.rest_controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import bachelor_degree.DTO.ClassificationDTO;
import bachelor_degree.model.DAO.ClassificationDAO;
import bachelor_degree.model.DAO.ProfessorDAO;
import bachelor_degree.model.DAO.QuestionsCategoryDAO;
import bachelor_degree.model.persistence.Classification;
import bachelor_degree.model.persistence.Student;
import bachelor_degree.services.MailService;
import bachelor_degree.utils.configuration.UrlMappings;
import bachelor_degree.utils.convertors.ClassificationConvertor;

@RestController
public class ClassificationController {

	@Autowired
	private ClassificationDAO classificationDAO;
	
	@Autowired
	private QuestionsCategoryDAO questionsCategoryDAO;
	
	@Autowired
	private ProfessorDAO professorDAO;
	
	@Autowired
	private MailService mailService;
	
	@RequestMapping(value = UrlMappings.SAVE_TEST_RESULTS_OF_ONE_STUDENT, method = RequestMethod.POST)
	public void saveTestResults(HttpServletRequest request, @ModelAttribute ClassificationDTO classificationDTO){
		
		Student loggedInStudent = (Student)request.getSession().getAttribute("student");
		Classification classification = ClassificationConvertor.convertClassificationDTOToEntity(classificationDTO);
		
		if (loggedInStudent != null){
			classification.setFirstName(loggedInStudent.getFirstName());
			classification.setLastName(loggedInStudent.getLastName());
			classification.setEmail(loggedInStudent.getEmail());
		}
		
		classificationDAO.save(classification);
 	}
	
	@RequestMapping(value = UrlMappings.SHOW_ALL_TEST_RESULTS, method = RequestMethod.GET)
	public List<ClassificationDTO> showAllTestResults(){
		List<Classification> classifications = classificationDAO.getAllClassifications();
		return ClassificationConvertor.convertClassificationToDTO(classifications);
 	}
	
	@RequestMapping(value = UrlMappings.GET_ALL_PROFESSORS_LIST , method = RequestMethod.GET)
	public List<String> getAllProfessorsMailList(){
		List<String> professorsMailList = professorDAO.getProfessorsMailList();
		return professorsMailList;
	}
	
	@RequestMapping(value = UrlMappings.SEND_EMAIL_WITH_TEST_RESULTS, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void sendEmailWithTestResults(HttpServletRequest request, 
			@ModelAttribute ClassificationDTO classificationDTO){
		
		Student loggedInStudent = (Student)request.getSession().getAttribute("student");
        String professorEmail = null;
        
		if (loggedInStudent != null){
			professorEmail = classificationDTO.getEmail();
			classificationDTO.setFirstName(loggedInStudent.getFirstName());
			classificationDTO.setLastName(loggedInStudent.getLastName());
			classificationDTO.setEmail(loggedInStudent.getEmail());
		}
		
		mailService.sendMail(professorEmail, classificationDTO);
	}
} 
