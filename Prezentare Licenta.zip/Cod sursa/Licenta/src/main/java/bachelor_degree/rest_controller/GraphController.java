package bachelor_degree.rest_controller;

import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bachelor_degree.DTO.AnswerDTO;
import bachelor_degree.DTO.CategoryDTO;
import bachelor_degree.DTO.CorrectAnswerDTO;
import bachelor_degree.model.DAO.AnswerDAO;
import bachelor_degree.model.DAO.CategoryDAO;
import bachelor_degree.model.DAO.QuestionDAO;
import bachelor_degree.model.persistence.Answer;
import bachelor_degree.model.persistence.Category;
import bachelor_degree.model.persistence.CorrectAnswer;
import bachelor_degree.utils.configuration.UrlMappings;
import bachelor_degree.utils.convertors.AnswerConvertor;
import bachelor_degree.utils.convertors.CategoryConvertor;
import bachelor_degree.utils.convertors.CorrectAnswerConvertor;

@RestController
public class GraphController {

	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private QuestionDAO questionDAO;
	
	@Autowired
	private AnswerDAO answerDAO;
	
	@RequestMapping(value = UrlMappings.RETRIEVE_CATEGORIES_DATA, method = RequestMethod.GET)
	public List<CategoryDTO> retrieveCategoriesData(){
		List<Category> categoriesData = categoryDAO.getGraphCategories();
		return CategoryConvertor.convertCategoryToDTO(categoriesData);
 	}
	
	@RequestMapping(value = UrlMappings.RETRIEVE_QUESTION_ANSWERS, method = RequestMethod.GET)
	public List<AnswerDTO> retrieveQuestionAnswers(@RequestParam("question_id") long questionId){
		List<Answer> answers = answerDAO.getAnswersOrderedById(questionId);
		return AnswerConvertor.convertAnswerToDTO(answers);
	}
	
	@RequestMapping(value = UrlMappings.RETRIEVE_QUESTION_CORRECT_ANSWER, method = RequestMethod.GET)
	public CorrectAnswerDTO retrieveQuestionCorrectAnswer(@RequestParam("question_id") long questionId){
		CorrectAnswer correctAnswer = questionDAO.findById(questionId).getCorrectAnswer();
		return CorrectAnswerConvertor.convertOneCorrectAnswerToDTO(correctAnswer);
	}
}
