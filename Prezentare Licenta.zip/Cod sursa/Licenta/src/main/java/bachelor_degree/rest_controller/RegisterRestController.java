package bachelor_degree.rest_controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import bachelor_degree.DTO.StudentDTO;
import bachelor_degree.model.persistence.Student;
import bachelor_degree.services.StudentService;
import bachelor_degree.utils.configuration.UrlMappings;
import bachelor_degree.utils.convertors.StudentConvertor;

@RestController
public class RegisterRestController {
	
	@Autowired
	private StudentConvertor studentConvertor;
	
	@Autowired
	private StudentService studentService;

	@RequestMapping(value = UrlMappings.REGISTER_NEW_STUDENT, method = RequestMethod.POST)
	public Map<String,Boolean> registerNewStudent(@ModelAttribute StudentDTO studentDTO){
		
		Map<String,Boolean> response = new HashMap<>();
		
		Student newStudent = StudentConvertor.convertStudentDTO(studentDTO);
		response.put("response", studentService.addNewStudent(newStudent));
		
		return response;
	}
}
