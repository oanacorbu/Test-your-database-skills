package bachelor_degree.DTO;

import java.util.List;

import org.springframework.stereotype.Component;

import bachelor_degree.model.persistence.CategoryLevel;

@Component
public class CategoryDTO {

	private String categoryName;
	private List<CategoryLevelDTO> categoryLevel;
	
	public CategoryDTO(){}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<CategoryLevelDTO> getCategoryLevel() {
		return categoryLevel;
	}

	public void setCategoryLevel(List<CategoryLevelDTO> categoryLevel) {
		this.categoryLevel = categoryLevel;
	}
}
