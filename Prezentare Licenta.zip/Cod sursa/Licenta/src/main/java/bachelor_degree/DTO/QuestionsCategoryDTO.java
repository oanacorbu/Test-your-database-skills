package bachelor_degree.DTO;

import org.springframework.stereotype.Component;

@Component
public class QuestionsCategoryDTO {

	private Long id;
	private String categoryName;
	private Long nrOfDifficult;
	private Long nrOfMedium;
	private Long nrOfSimple;
	
	public QuestionsCategoryDTO(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Long getNrOfDifficult() {
		return nrOfDifficult;
	}

	public void setNrOfDifficult(Long nrOfDifficult) {
		this.nrOfDifficult = nrOfDifficult;
	}

	public Long getNrOfMedium() {
		return nrOfMedium;
	}

	public void setNrOfMedium(Long nrOfMedium) {
		this.nrOfMedium = nrOfMedium;
	}

	public Long getNrOfSimple() {
		return nrOfSimple;
	}

	public void setNrOfSimple(Long nrOfSimple) {
		this.nrOfSimple = nrOfSimple;
	}
}
