package bachelor_degree.DTO;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class QuestionDTO {
	
	private Long id;
	private String name;
	private String description;
	private Integer levelPosition;
	private List<AnswerDTO> answers;
	private CorrectAnswerDTO correctAnswer;
    private String difficulty;
	private Integer score;
	private String image_relative_path;
	
	public QuestionDTO(){}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getLevelPosition() {
		return levelPosition;
	}

	public void setLevelPosition(Integer levelPosition) {
		this.levelPosition = levelPosition;
	}

	public List<AnswerDTO> getAnswers() {
		return answers;
	}

	public void setAnswers(List<AnswerDTO> answers) {
		this.answers = answers;
	}

	public CorrectAnswerDTO getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(CorrectAnswerDTO correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public String getImage_relative_path() {
		return image_relative_path;
	}

	public void setImage_relative_path(String image_relative_path) {
		this.image_relative_path = image_relative_path;
	}
}
