package bachelor_degree.DTO;

import org.springframework.stereotype.Component;

@Component
public class CorrectAnswerDTO {

	private AnswerDTO answer;
	
	public CorrectAnswerDTO(){}

	public AnswerDTO getAnswer() {
		return answer;
	}

	public void setAnswer(AnswerDTO answer) {
		this.answer = answer;
	}
}
