package bachelor_degree.DTO;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CategoryLevelDTO {

	private Long levelNumber;
	private List<QuestionDTO> questionsDTO;
	
	public CategoryLevelDTO(){}

	public Long getLevelNumber() {
		return levelNumber;
	}

	public void setLevelNumber(Long levelNumber) {
		this.levelNumber = levelNumber;
	}
	
	public List<QuestionDTO> getQuestionsDTO() {
		return questionsDTO;
	}

	public void setQuestionsDTO(List<QuestionDTO> questionsDTO) {
		this.questionsDTO = questionsDTO;
	}
}
