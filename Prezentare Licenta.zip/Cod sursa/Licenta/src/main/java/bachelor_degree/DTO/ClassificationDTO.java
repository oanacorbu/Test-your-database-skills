package bachelor_degree.DTO;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class ClassificationDTO {

	private Long id;
	private String firstName;
	private String lastName;
	private String email;
	private String categoryname;
	private Long obtainedScore;
	private Long solvedDifficultQuestions;
	private Long solvedMediumQuestions;
	private Long solvedSimpleQuestions;
	private List<Map<String,String>> completeSituationOnTest;
	
	public ClassificationDTO(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public Long getObtainedScore() {
		return obtainedScore;
	}

	public void setObtainedScore(Long obtainedScore) {
		this.obtainedScore = obtainedScore;
	}

	public Long getSolvedDifficultQuestions() {
		return solvedDifficultQuestions;
	}

	public void setSolvedDifficultQuestions(Long solvedDifficultQuestions) {
		this.solvedDifficultQuestions = solvedDifficultQuestions;
	}

	public Long getSolvedMediumQuestions() {
		return solvedMediumQuestions;
	}

	public void setSolvedMediumQuestions(Long solvedMediumQuestions) {
		this.solvedMediumQuestions = solvedMediumQuestions;
	}

	public Long getSolvedSimpleQuestions() {
		return solvedSimpleQuestions;
	}

	public void setSolvedSimpleQuestions(Long solvedSimpleQuestions) {
		this.solvedSimpleQuestions = solvedSimpleQuestions;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Map<String,String>> getCompleteSituationOnTest() {
		return completeSituationOnTest;
	}

	public void setCompleteSituationOnTest(List<Map<String,String>> completeSituationOnTest) {
		this.completeSituationOnTest = completeSituationOnTest;
	}
}
