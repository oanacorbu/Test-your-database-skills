package bachelor_degree.DTO;

import org.springframework.stereotype.Component;

@Component
public class AnswerDTO {

	private String name;
	private Long id;
	
	public AnswerDTO(){}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
