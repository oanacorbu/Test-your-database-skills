package bachelor_degree.services;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import bachelor_degree.DTO.ClassificationDTO;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;

@Service
@EnableAsync
public class MailService {

	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private Configuration emailTemplateConfigurer;
	
	private Logger logger = Logger.getLogger(getClass().getName());
	
	public JavaMailSender getMailSender(){
		return mailSender;
	}
	
	public void setMailSender(JavaMailSender mailSender){
		this.mailSender = mailSender;
	}
	
	public Configuration getEmailTemplateConfigurer(){
		return emailTemplateConfigurer;
	}
	
	public void setEmailTemplateConfigurer(Configuration emailTemplateConfigurer){
		this.emailTemplateConfigurer = emailTemplateConfigurer;
	}
	
	// complete mail sender
	@Async
	public void sendMail(final String professorEmail, final ClassificationDTO classificationDTO) 
			throws MailSendException{
		MimeMessagePreparator preparator = new MimeMessagePreparator(){

			@Override
			public void prepare(MimeMessage message) throws MessagingException,
				IOException{
				try{
					MimeMessageHelper messageHelper = new MimeMessageHelper(
							message,true);
					messageHelper.setTo(professorEmail);
					messageHelper.setFrom(classificationDTO.getEmail());
					
					Map<String, Object> mailBodyMap = new HashMap<>();
					mailBodyMap.put("studentName", classificationDTO.getFirstName() + " ");
					mailBodyMap.put("studentSurname", classificationDTO.getLastName() + " ");
					mailBodyMap.put("category", classificationDTO.getCategoryname());
					mailBodyMap.put("score", classificationDTO.getObtainedScore());
					mailBodyMap.put("solved_simple_questions", classificationDTO.getSolvedSimpleQuestions());
					mailBodyMap.put("solved_medium_questions", classificationDTO.getSolvedMediumQuestions());
					mailBodyMap.put("solved_difficult_questions", classificationDTO.getSolvedDifficultQuestions());
					
					Map<String, Object> results;
					StringBuilder sb = new StringBuilder();
					
					for (int contor = 0; contor < classificationDTO.getCompleteSituationOnTest().size(); contor++){
						results = new HashMap<String, Object>(classificationDTO.getCompleteSituationOnTest().get(contor));
						sb.append("Question name    : " + results.get("question_name") + "<br>")
						  .append("Question score    : " + results.get("question_score") + "<br>")
						  .append("Student answer : " + results.get("correct_answer") + "<br>")
						  .append("Correct answer : " + results.get("student_answer") + "<br><br>");
					}
					mailBodyMap.put("complete_situation", sb.toString());
					
					
					String mailBody = FreeMarkerTemplateUtils
							.processTemplateIntoString(
									emailTemplateConfigurer.getTemplate(
											"mail_template.html","UTF-8"), mailBodyMap);
					
					messageHelper.setText(mailBody, true);
					messageHelper.setSubject("Test results");
					messageHelper.setSentDate(new Date());
					
				}catch (TemplateException ex) {
					logger.debug("Email template exception: ");
					logger.error(ex.getMessage(), ex);
					ex.printStackTrace();
				}
			}
		};
		this.mailSender.send(preparator);
	}
}
