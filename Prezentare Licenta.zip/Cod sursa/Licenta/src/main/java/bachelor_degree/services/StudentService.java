package bachelor_degree.services;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bachelor_degree.model.DAO.StudentDAO;
import bachelor_degree.model.persistence.Student;
import bachelor_degree.utils.security.EncryptionUtils;

@Service
public class StudentService {

	@Autowired
	private StudentDAO studentDAO;
	
	public StudentService(){}
	
	public boolean addNewStudent(Student newStudent){
		try{
			newStudent.setPassword(EncryptionUtils.getSHA256Hash(newStudent.getPassword()));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if (studentDAO.getStudentByEmail(newStudent.getEmail()) != null){
			return false;
		}
		else {
			studentDAO.save(newStudent);
			return true;
		}
	}
	
	public List<Student> getStudentByNameAndSurname(
			String firstName, String lastName){
		return studentDAO.getStudentByNameAndSurname(firstName, lastName);
	}
	
	public Student getStudentByEmailAndPassword(
			String email, String password){
		String hashPassword = null;
		try {
			hashPassword = EncryptionUtils.getSHA256Hash(password);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return studentDAO.getStudentByEmailAndPassword(email, hashPassword);
	}
	
	public Student getStudentByEmail(String email){
		return studentDAO.getStudentByEmail(email);
	}
}
