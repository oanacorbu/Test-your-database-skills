package bachelor_degree.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import bachelor_degree.model.DAO.ClassificationDAO;
import bachelor_degree.model.persistence.Classification;
import bachelor_degree.model.persistence.Student;
import bachelor_degree.utils.configuration.FileSystemMappings;
import bachelor_degree.utils.configuration.UrlMappings;
import bachelor_degree.utils.convertors.ClassificationConvertor;

@Controller
public class HomeController {
	
	@Autowired
	private ClassificationDAO classificationDAO;
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(HomeController.class);
	
	@RequestMapping(value = {UrlMappings.EMPTY_STRING,UrlMappings.DEFAULT_PAGE,UrlMappings.HOME})
	public ModelAndView goToHomePage(HttpServletRequest request){
		Student loggedInStudent = (Student)request.getSession().getAttribute("student");
		ModelAndView modelAndView = new ModelAndView();
		
		if (loggedInStudent != null){
			modelAndView.setViewName(FileSystemMappings.HOME);
			
			List<Classification> classifications = classificationDAO.getAllClassifications();
			modelAndView.addObject("testResults", ClassificationConvertor.convertClassificationToDTO(classifications));
			return modelAndView;
		}
		else {
			modelAndView.setViewName("redirect:" + UrlMappings.LOGIN);
			return modelAndView;
		}
	}
}
