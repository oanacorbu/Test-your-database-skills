/* professors */

INSERT INTO professors (id, email) VALUES (1, 'corbu_oana_andreea@yahoo.com');
INSERT INTO professors (id, email) VALUES (2, 'corbu.oana.andreea@gmail.com');
INSERT INTO professors (id, email) VALUES (3, 'Oana.Corbu@endava.com');

/* categories */
INSERT INTO categories (id, category_name) VALUES (1, 'Normalization');
INSERT INTO categories (id, category_name) VALUES (2, 'Queries');
INSERT INTO categories (id, category_name) VALUES (3, 'ACID - Transactions');
INSERT INTO categories (id, category_name) VALUES (4, 'Indexes');
INSERT INTO categories (id, category_name) VALUES (5, 'B-trees');
INSERT INTO categories (id, category_name) VALUES (6, 'Data mining');
INSERT INTO categories (id, category_name) VALUES (7, 'Big data analytics');

/* levels */
INSERT INTO categories_levels (id, level_number,category_id) VALUES (1, 1, 1);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (2, 2, 1);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (3, 3, 1);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (4, 4, 1);

INSERT INTO categories_levels (id, level_number,category_id) VALUES (5, 5, 2);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (6, 6, 2);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (7, 7, 2);

INSERT INTO categories_levels (id, level_number,category_id) VALUES (8, 8, 3);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (9, 9, 3);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (10, 10, 3);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (11, 11, 3);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (12, 12, 3);

INSERT INTO categories_levels (id, level_number,category_id) VALUES (13, 13, 4);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (14, 14, 4);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (15, 15, 4);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (16, 16, 4);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (17, 17, 4);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (18, 18, 4);

INSERT INTO categories_levels (id, level_number,category_id) VALUES (19, 19, 5);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (20, 20, 5);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (21, 21, 5);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (22, 22, 5);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (23, 23, 5);

INSERT INTO categories_levels (id, level_number,category_id) VALUES (24, 24, 6);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (25, 25, 6);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (26, 26, 6);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (27, 27, 6);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (28, 28, 6);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (29, 29, 6);

INSERT INTO categories_levels (id, level_number,category_id) VALUES (31, 31, 7);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (32, 32, 7);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (33, 33, 7);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (34, 34, 7);
INSERT INTO categories_levels (id, level_number,category_id) VALUES (35, 35, 7);


/* questions */

/* category 1 */
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (1, 'Question 1 description', 'simple', 1, 'Question 1', 4, 1);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (2, 'Question 2 description', 'simple', 2, 'Question 2', 4, 1);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (3, 'Question 3 description', 'medium', 3, 'Question 3', 6, 1);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (4, 'Question 4 description', 'medium', 4, 'Question 4', 7, 1);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (5, 'Question 5 description', 'difficult', 5, 'Question 5', 9, 1);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (6, 'Question 6 description', 'simple', 1, 'Question 6', 2, 2);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (7, 'Question 7 description', 'simple', 2, 'Question 7', 3, 2);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (8, 'Question 8 description', 'medium', 3, 'Question 8', 5, 2);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (9, 'Question 9 description', 'medium', 4, 'Question 9', 6, 2);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (10, 'Question 10 description', 'difficult', 5, 'Question 10', 8, 2);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (11, 'Question 11 description', 'difficult', 6, 'Question 11', 9, 2);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (12, 'Question 12 description', 'simple', 1, 'Question 12', 2, 3);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (13, 'Question 13 description', 'medium', 2, 'Question 13', 5, 3);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (14, 'Question 14 description', 'medium', 3, 'Question 14', 6, 3);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (15, 'Question 15 description', 'difficult', 4, 'Question 15', 8, 3);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (16, 'Question 16 description', 'difficult', 5, 'Question 16', 9, 3);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (17, 'Question 17 description', 'medium', 1, 'Question 17', 7, 4);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (18, 'Question 18 description', 'medium', 2, 'Question 18', 7, 4);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (19, 'Question 19 description', 'difficult', 3, 'Question 19', 9, 4);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (20, 'Question 20 description', 'difficult', 4, 'Question 20', 10, 4);


/* category 2 */
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (21, 'Index', 'simple', 1, 'What is an index?', 1, 5);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (22, 'Joins', 'simple', 2, 'If you join a table to itself, what kind of join are you using?', 2, 5);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (23, 'Views', 'medium', 3, 'What is a view?', 5, 5);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level,image_path) 
VALUES (24, 'Queries', 'medium', 4, 'Which of the following 3 SQL statements is correct?', 6, 5, 'exercise30.png');
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (25, 'Keys', 'medium', 5, 'The primary - foreign key relations are used to ...', 7, 5);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (26, 'Triggers', 'difficult', 6, 'There are triggers for...', 8, 5);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (27, 'Theory', 'simple', 1, 'What does SQL stand for?', 2, 6);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (28, 'Theory', 'medium', 2, 'What does the CREATE TABLE statement do?', 3, 6);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (29, 'Theory', 'medium', 3, 'What does the SQL FROM clause do? Specifies...', 6, 6);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (30, 'Functions', 'difficult', 4, 'Which of the following is a SQL aggregate function?', 8, 6);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (31, 'Functions', 'difficult', 5, 'The AVG SQL function returns the ...', 9, 6);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (32, 'Keywords', 'simple', 1, 'Which SQL keyword is used to retrieve only unique values?', 2, 7);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (33, 'Keywords', 'medium', 2, 'Which SQL keyword is used to specify conditional search?', 5, 7);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (34, 'Clauses', 'medium', 3, 'What does the HAVING clause do?', 6, 7);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (35, 'Theory', 'difficult', 4, 'Which of the following SQL clauses is used to sort a result set?', 8, 7);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (36, 'Theory', 'difficult', 5, 'Which of the following is not a SQL keyword or SQL clause?', 9, 7);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (37, 'Theory', 'difficult', 6, 'The SQL DROP TABLE clause is used to...', 10, 7);


/* category 3 */
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (38, 'Question 38 description', 'simple', 1, 'Question 38', 1, 8);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (39, 'Question 39 description', 'simple', 2, 'Question 39', 2, 8);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (40, 'Question 40 description', 'medium', 3, 'Question 40', 5, 8);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (41, 'Question 41 description', 'medium', 4, 'Question 41', 6, 8);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (42, 'Question 42 description', 'medium', 5, 'Question 42', 7, 8);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (43, 'Question 43 description', 'difficult', 6, 'Question 43', 8, 8);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (44, 'Question 44 description', 'difficult', 7, 'Question 44', 8, 8);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (45, 'Question 45 description', 'medium', 1, 'Question 45', 5, 9);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (46, 'Question 46 description', 'medium', 2, 'Question 46', 7, 9);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (47, 'Question 47 description', 'difficult', 3, 'Question 47', 9, 9);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (48, 'Question 48 description', 'difficult', 4, 'Question 48', 9, 9);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (49, 'Question 49 description', 'simple', 1, 'Question 49', 2, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (50, 'Question 50 description', 'simple', 2, 'Question 50', 3, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (51, 'Question 51 description', 'medium', 3, 'Question 51', 5, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (52, 'Question 52 description', 'medium', 4, 'Question 52', 6, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (53, 'Question 53 description', 'medium', 5, 'Question 53', 7, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (54, 'Question 54 description', 'difficult', 6, 'Question 54', 8, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (55, 'Question 55 description', 'difficult', 7, 'Question 55', 8, 10);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (56, 'Question 56 description', 'difficult', 8, 'Question 56', 9, 10);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (57, 'Question 57 description', 'simple', 1, 'Question 57', 1, 11);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (58, 'Question 58 description', 'simple', 2, 'Question 58', 2, 11);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (59, 'Question 59 description', 'medium', 3, 'Question 59', 5, 11);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (60, 'Question 60 description', 'medium', 4, 'Question 60', 6, 11);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (61, 'Question 61 description', 'difficult', 5, 'Question 61', 8, 11);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (62, 'Question 62 description', 'medium', 1, 'Question 62', 5, 12);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (63, 'Question 63 description', 'medium', 2, 'Question 63', 6, 12);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (64, 'Question 64 description', 'difficult', 3, 'Question 64', 8, 12);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (65, 'Question 65 description', 'difficult', 4, 'Question 65', 8, 12);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (66, 'Question 66 description', 'difficult', 5, 'Question 66', 10, 12);


/* category 4 */
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (67, 'Question 67 description', 'simple', 1, 'Question 67', 2, 13);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (68, 'Question 68 description', 'simple', 2, 'Question 68', 3, 13);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (69, 'Question 69 description', 'medium', 3, 'Question 69', 5, 13);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (70, 'Question 70 description', 'medium', 4, 'Question 70', 6, 13);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (71, 'Question 71 description', 'medium', 5, 'Question 71', 7, 13);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (72, 'Question 72 description', 'difficult', 6, 'Question 72', 8, 13);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (73, 'Question 73 description', 'simple', 1, 'Question 73', 1, 14);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (74, 'Question 74 description', 'simple', 2, 'Question 74', 2, 14);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (75, 'Question 75 description', 'simple', 3, 'Question 75', 2, 14);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (76, 'Question 76 description', 'medium', 4, 'Question 76', 5, 14);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (77, 'Question 77 description', 'medium', 5, 'Question 77', 6, 14);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (78, 'Question 78 description', 'medium', 6, 'Question 78', 6, 14);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (79, 'Question 79 description', 'difficult', 7, 'Question 79', 8, 14);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (80, 'Question 80 description', 'simple', 1, 'Question 80', 2, 15);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (81, 'Question 81 description', 'simple', 2, 'Question 81', 3, 15);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (82, 'Question 82 description', 'medium', 3, 'Question 82', 5, 15);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (83, 'Question 83 description', 'medium', 4, 'Question 83', 6, 15);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (84, 'Question 84 description', 'difficult', 5, 'Question 84', 8, 15);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (85, 'Question 85 description', 'medium', 1, 'Question 85', 5, 16);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (86, 'Question 86 description', 'medium', 2, 'Question 86', 6, 16);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (87, 'Question 87 description', 'medium', 3, 'Question 87', 7, 16);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (88, 'Question 88 description', 'medium', 1, 'Question 88', 5, 17);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (89, 'Question 89 description', 'medium', 2, 'Question 89', 6, 17);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (90, 'Question 90 description', 'medium', 3, 'Question 90', 7, 17);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (91, 'Question 91 description', 'difficult', 4, 'Question 91', 8, 17);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (92, 'Question 92 description', 'difficult', 5, 'Question 92', 9, 17);


INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (93, 'Question 93 description', 'simple', 1, 'Question 93', 2, 18);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (94, 'Question 94 description', 'medium', 2, 'Question 94', 5, 18);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (95, 'Question 95 description', 'medium', 3, 'Question 95', 6, 18);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (96, 'Question 96 description', 'medium', 4, 'Question 96', 7, 18);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (97, 'Question 97 description', 'difficult', 5, 'Question 97', 8, 18);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (98, 'Question 98 description', 'difficult', 6, 'Question 98', 9, 18);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (99, 'Question 99 description', 'difficult', 7, 'Question 99', 9, 18);

/* category 5 */
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (100, 'Question 100 description', 'simple', 1, 'Question 100', 2, 19);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (101, 'Question 101 description', 'simple', 2, 'Question 101', 2, 19);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (102, 'Question 102 description', 'medium', 3, 'Question 102', 5, 19);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (103, 'Question 103 description', 'medium', 4, 'Question 103', 5, 19);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (104, 'Question 104 description', 'medium', 5, 'Question 104', 6, 19);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (105, 'Question 105 description', 'difficult', 6, 'Question 105', 8, 19);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (106, 'Question 106 description', 'difficult', 7, 'Question 106', 9, 19);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (107, 'Question 107 description', 'simple', 1, 'Question 107', 2, 20);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (108, 'Question 108 description', 'simple', 2, 'Question 108', 2, 20);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (109, 'Question 109 description', 'medium', 3, 'Question 109', 5, 20);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (110, 'Question 110 description', 'medium', 4, 'Question 110', 6, 20);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (111, 'Question 111 description', 'difficult', 5, 'Question 111', 9, 20);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (112, 'Question 112 description', 'simple', 1, 'Question 112', 2, 21);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (113, 'Question 113 description', 'medium', 2, 'Question 113', 5, 21);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (114, 'Question 114 description', 'medium', 3, 'Question 114', 6, 21);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (115, 'Question 115 description', 'difficult', 4, 'Question 115', 8, 21);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (116, 'Question 116 description', 'simple', 1, 'Question 116', 1, 22);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (117, 'Question 117 description', 'simple', 2, 'Question 117', 2, 22);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (118, 'Question 118 description', 'medium', 3, 'Question 118', 6, 22);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (119, 'Question 119 description', 'medium', 4, 'Question 119', 7, 22);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (120, 'Question 120 description', 'difficult', 5, 'Question 120', 8, 22);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (121, 'Question 121 description', 'difficult', 6, 'Question 121', 9, 22);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (122, 'Question 122 description', 'simple', 1, 'Question 122', 2, 23);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (123, 'Question 123 description', 'medium', 2, 'Question 123', 5, 23);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (124, 'Question 124 description', 'medium', 3, 'Question 124', 6, 23);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (125, 'Question 125 description', 'difficult', 4, 'Question 125', 9, 23);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (126, 'Question 126 description', 'difficult', 5, 'Question 126', 10, 23);

/* category 6 */
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (127, 'Question 127 description', 'simple', 1, 'Question 127', 1, 24);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (128, 'Question 128 description', 'simple', 2, 'Question 128', 2, 24);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (129, 'Question 129 description', 'medium', 3, 'Question 129', 5, 24);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (130, 'Question 130 description', 'medium', 4, 'Question 130', 6, 24);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (131, 'Question 131 description', 'medium', 5, 'Question 131', 7, 24);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (132, 'Question 132 description', 'difficult', 6, 'Question 132', 8, 24);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (133, 'Question 133 description', 'simple', 1, 'Question 133', 2, 25);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (134, 'Question 134 description', 'simple', 2, 'Question 134', 3, 25);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (135, 'Question 135 description', 'medium', 3, 'Question 135', 5, 25);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (136, 'Question 136 description', 'medium', 4, 'Question 136', 6, 25);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (137, 'Question 137 description', 'difficult', 5, 'Question 137', 8, 25);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (138, 'Question 138 description', 'simple', 1, 'Question 138', 2, 26);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (139, 'Question 139 description', 'simple', 2, 'Question 139', 3, 26);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (140, 'Question 140 description', 'medium', 3, 'Question 140', 6, 26);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (141, 'Question 141 description', 'medium', 4, 'Question 141', 7, 26);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (142, 'Question 142 description', 'simple', 1, 'Question 142', 2, 27);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (143, 'Question 143 description', 'medium', 2, 'Question 143', 5, 27);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (144, 'Question 144 description', 'medium', 3, 'Question 144', 6, 27);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (145, 'Question 145 description', 'medium', 4, 'Question 145', 7, 27);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (146, 'Question 146 description', 'difficult', 5, 'Question 146', 8, 27);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (147, 'Question 147 description', 'simple', 1, 'Question 147', 2, 28);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (148, 'Question 148 description', 'medium', 2, 'Question 148', 6, 28);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (149, 'Question 149 description', 'medium', 3, 'Question 149', 7, 28);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (150, 'Question 150 description', 'difficult', 4, 'Question 150', 9, 28);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (151, 'Question 151 description', 'simple', 1, 'Question 151', 3, 29);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (152, 'Question 152 description', 'medium', 2, 'Question 152', 6, 29);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (153, 'Question 153 description', 'medium', 3, 'Question 153', 7, 29);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (154, 'Question 154 description', 'difficult', 4, 'Question 154', 8, 29);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (155, 'Question 155 description', 'difficult', 5, 'Question 155', 9, 29);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (156, 'Question 156 description', 'difficult', 6, 'Question 156', 9, 29);


/* categoria 7 */

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (161, 'Question 161 description', 'simple', 1, 'Question 161', 2, 31);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (162, 'Question 162 description', 'simple', 2, 'Question 162', 3, 31);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (163, 'Question 163 description', 'medium', 3, 'Question 163', 5, 31);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (164, 'Question 164 description', 'medium', 4, 'Question 164', 6, 31);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (165, 'Question 165 description', 'medium', 5, 'Question 165', 7, 31);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (166, 'Question 166 description', 'simple', 1, 'Question 166', 2, 32);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (167, 'Question 167 description', 'medium', 2, 'Question 167', 5, 32);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (168, 'Question 168 description', 'medium', 3, 'Question 168', 6, 32);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (169, 'Question 169 description', 'medium', 4, 'Question 169', 7, 32);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (170, 'Question 170 description', 'difficult', 5, 'Question 170', 8, 32);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (171, 'Question 171 description', 'simple', 1, 'Question 171', 2, 33);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (172, 'Question 172 description', 'simple', 2, 'Question 172', 3, 33);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (173, 'Question 173 description', 'medium', 3, 'Question 173', 5, 33);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (174, 'Question 174 description', 'medium', 4, 'Question 174', 6, 33);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (175, 'Question 175 description', 'difficult', 5, 'Question 175', 8, 33);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (176, 'Question 176 description', 'difficult', 6, 'Question 176', 9, 33);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (177, 'Question 177 description', 'simple', 1, 'Question 177', 2, 34);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (178, 'Question 178 description', 'medium', 2, 'Question 178', 5, 34);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (179, 'Question 179 description', 'medium', 3, 'Question 179', 6, 34);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (180, 'Question 180 description', 'difficult', 4, 'Question 180', 8, 34);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (181, 'Question 181 description', 'difficult', 5, 'Question 181', 9, 34);

INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (182, 'Question 182 description', 'simple', 1, 'Question 182', 2, 35);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (183, 'Question 183 description', 'medium', 2, 'Question 183', 5, 35);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (184, 'Question 184 description', 'difficult', 3, 'Question 184', 9, 35);
INSERT INTO questions (id, short_description, difficulty, level_position, name, score, category_level) 
VALUES (185, 'Question 185 description', 'difficult', 4, 'Question 185', 10, 35);


/* insert answers for questions */

INSERT INTO answers(id,name,question_id) VALUES (1,'answer1',1);
INSERT INTO answers(id,name,question_id) VALUES (2,'answer2',1);
INSERT INTO answers(id,name,question_id) VALUES (3,'answer3',1);
INSERT INTO answers(id,name,question_id) VALUES (4,'answer4',1);
INSERT INTO answers(id,name,question_id) VALUES (5,'answer5',2);
INSERT INTO answers(id,name,question_id) VALUES (6,'answer6',2);
INSERT INTO answers(id,name,question_id) VALUES (7,'answer7',2);
INSERT INTO answers(id,name,question_id) VALUES (8,'answer8',2);
INSERT INTO answers(id,name,question_id) VALUES (9,'answer9',3);
INSERT INTO answers(id,name,question_id) VALUES (10,'answer10',3);
INSERT INTO answers(id,name,question_id) VALUES (11,'answer11',3);
INSERT INTO answers(id,name,question_id) VALUES (12,'answer12',3);
INSERT INTO answers(id,name,question_id) VALUES (13,'answer13',3);
INSERT INTO answers(id,name,question_id) VALUES (14,'answer14',4);
INSERT INTO answers(id,name,question_id) VALUES (15,'answer15',4);
INSERT INTO answers(id,name,question_id) VALUES (16,'answer16',4);
INSERT INTO answers(id,name,question_id) VALUES (17,'answer17',4);
INSERT INTO answers(id,name,question_id) VALUES (18,'answer18',5);
INSERT INTO answers(id,name,question_id) VALUES (19,'answer19',5);
INSERT INTO answers(id,name,question_id) VALUES (20,'answer20',5);
INSERT INTO answers(id,name,question_id) VALUES (21,'answer21',6);
INSERT INTO answers(id,name,question_id) VALUES (22,'answer22',6);
INSERT INTO answers(id,name,question_id) VALUES (23,'answer23',6);
INSERT INTO answers(id,name,question_id) VALUES (24,'answer24',7);
INSERT INTO answers(id,name,question_id) VALUES (25,'answer25',7);
INSERT INTO answers(id,name,question_id) VALUES (26,'answer26',7);
INSERT INTO answers(id,name,question_id) VALUES (27,'answer27',7);
INSERT INTO answers(id,name,question_id) VALUES (28,'answer28',7);
INSERT INTO answers(id,name,question_id) VALUES (29,'answer29',8);
INSERT INTO answers(id,name,question_id) VALUES (30,'answer30',8);
INSERT INTO answers(id,name,question_id) VALUES (31,'answer31',8);
INSERT INTO answers(id,name,question_id) VALUES (32,'answer32',8);
INSERT INTO answers(id,name,question_id) VALUES (33,'answer33',9);
INSERT INTO answers(id,name,question_id) VALUES (34,'answer34',9);
INSERT INTO answers(id,name,question_id) VALUES (35,'answer35',9);
INSERT INTO answers(id,name,question_id) VALUES (36,'answer36',10);
INSERT INTO answers(id,name,question_id) VALUES (37,'answer37',10);
INSERT INTO answers(id,name,question_id) VALUES (38,'answer38',10);
INSERT INTO answers(id,name,question_id) VALUES (39,'answer39',10);
INSERT INTO answers(id,name,question_id) VALUES (40,'answer40',10);
INSERT INTO answers(id,name,question_id) VALUES (41,'answer41',11);
INSERT INTO answers(id,name,question_id) VALUES (42,'answer42',11);
INSERT INTO answers(id,name,question_id) VALUES (43,'answer43',11);
INSERT INTO answers(id,name,question_id) VALUES (44,'answer44',11);
INSERT INTO answers(id,name,question_id) VALUES (45,'answer45',12);
INSERT INTO answers(id,name,question_id) VALUES (46,'answer46',12);
INSERT INTO answers(id,name,question_id) VALUES (47,'answer47',12);
INSERT INTO answers(id,name,question_id) VALUES (48,'answer48',13);
INSERT INTO answers(id,name,question_id) VALUES (49,'answer49',13);
INSERT INTO answers(id,name,question_id) VALUES (50,'answer50',14);
INSERT INTO answers(id,name,question_id) VALUES (51,'answer51',14);
INSERT INTO answers(id,name,question_id) VALUES (52,'answer52',14);
INSERT INTO answers(id,name,question_id) VALUES (53,'answer53',14);
INSERT INTO answers(id,name,question_id) VALUES (54,'answer54',15);
INSERT INTO answers(id,name,question_id) VALUES (55,'answer55',15);
INSERT INTO answers(id,name,question_id) VALUES (56,'answer56',15);
INSERT INTO answers(id,name,question_id) VALUES (57,'answer57',15);
INSERT INTO answers(id,name,question_id) VALUES (58,'answer58',16);
INSERT INTO answers(id,name,question_id) VALUES (59,'answer59',16);
INSERT INTO answers(id,name,question_id) VALUES (60,'answer60',16);
INSERT INTO answers(id,name,question_id) VALUES (61,'answer61',17);
INSERT INTO answers(id,name,question_id) VALUES (62,'answer62',17);
INSERT INTO answers(id,name,question_id) VALUES (63,'answer63',17);
INSERT INTO answers(id,name,question_id) VALUES (64,'answer64',17);
INSERT INTO answers(id,name,question_id) VALUES (65,'answer65',18);
INSERT INTO answers(id,name,question_id) VALUES (66,'answer66',18);
INSERT INTO answers(id,name,question_id) VALUES (67,'answer67',18);
INSERT INTO answers(id,name,question_id) VALUES (68,'answer68',18);
INSERT INTO answers(id,name,question_id) VALUES (69,'answer69',19);
INSERT INTO answers(id,name,question_id) VALUES (70,'answer70',19);
INSERT INTO answers(id,name,question_id) VALUES (71,'answer71',20);
INSERT INTO answers(id,name,question_id) VALUES (72,'answer72',20);
INSERT INTO answers(id,name,question_id) VALUES (73,'answer73',20);

/* updates */
INSERT INTO answers(id,name,question_id) VALUES (74,'special way to join 2 tables',21);
INSERT INTO answers(id,name,question_id) VALUES (75,'table attribute that speeds-up search',21);
INSERT INTO answers(id,name,question_id) VALUES (76,'the same as alias',21);

INSERT INTO answers(id,name,question_id) VALUES (78,'self join',22);
INSERT INTO answers(id,name,question_id) VALUES (79,'selective join',22);
INSERT INTO answers(id,name,question_id) VALUES (80,'cannot join a table to itself',22);

INSERT INTO answers(id,name,question_id) VALUES (81,'special stored procedure',23);
INSERT INTO answers(id,name,question_id) VALUES (82,'database diagram',23);
INSERT INTO answers(id,name,question_id) VALUES (83,'virtual table',23);

INSERT INTO answers(id,name,question_id) VALUES (84,'1',24);
INSERT INTO answers(id,name,question_id) VALUES (85,'2',24);
INSERT INTO answers(id,name,question_id) VALUES (86,'3',24);

INSERT INTO answers(id,name,question_id) VALUES (88,'to index the database.',25);
INSERT INTO answers(id,name,question_id) VALUES (89,'cross-reference database tables.',25);
INSERT INTO answers(id,name,question_id) VALUES (90,'clean-up the database.',25);

INSERT INTO answers(id,name,question_id) VALUES (92,'insert and update only',26);
INSERT INTO answers(id,name,question_id) VALUES (93,'update and delete only',26);
INSERT INTO answers(id,name,question_id) VALUES (94,'update, delete and insert',26);
INSERT INTO answers(id,name,question_id) VALUES (95,'insert and delete only',26);

INSERT INTO answers(id,name,question_id) VALUES (97,'Strong Query Language',27);
INSERT INTO answers(id,name,question_id) VALUES (98,'Strict Query Language',27);
INSERT INTO answers(id,name,question_id) VALUES (99,'Structured Query Language',27);
INSERT INTO answers(id,name,question_id) VALUES (100,'Standard Query Language.',27);

INSERT INTO answers(id,name,question_id) VALUES (101,'Creates a database view',28);
INSERT INTO answers(id,name,question_id) VALUES (102,'Creates a stored procedure',28);
INSERT INTO answers(id,name,question_id) VALUES (103,'Creates a new database table',28);

INSERT INTO answers(id,name,question_id) VALUES (104,'the tables to retrieve rows from',29);
INSERT INTO answers(id,name,question_id) VALUES (105,'a search condition',29);
INSERT INTO answers(id,name,question_id) VALUES (106,'the columns we are retrieving',29);

INSERT INTO answers(id,name,question_id) VALUES (107,'RIGHT',30);
INSERT INTO answers(id,name,question_id) VALUES (108,'MIN',30);
INSERT INTO answers(id,name,question_id) VALUES (109,'CAST',30);
INSERT INTO answers(id,name,question_id) VALUES (110,'LEFT',30);

INSERT INTO answers(id,name,question_id) VALUES (111,'the sum of values in a column',31);
INSERT INTO answers(id,name,question_id) VALUES (112,'maximum value from a column',31);
INSERT INTO answers(id,name,question_id) VALUES (113,'average in the values in a group',31);

INSERT INTO answers(id,name,question_id) VALUES (114,'DISTINCT',32);
INSERT INTO answers(id,name,question_id) VALUES (115,'DISTINCTIVE',32);
INSERT INTO answers(id,name,question_id) VALUES (116,'UNIQUE',32);
INSERT INTO answers(id,name,question_id) VALUES (117,'DIFFERENT',32);

INSERT INTO answers(id,name,question_id) VALUES (119,'SEARCH',33);
INSERT INTO answers(id,name,question_id) VALUES (120,'FIND',33);
INSERT INTO answers(id,name,question_id) VALUES (121,'WHERE',33);
INSERT INTO answers(id,name,question_id) VALUES (122,'SELECT',33);

INSERT INTO answers(id,name,question_id) VALUES (123,'is used to select distinct values',34);
INSERT INTO answers(id,name,question_id) VALUES (124,'is used to join 2 or more tables',34);
INSERT INTO answers(id,name,question_id) VALUES (125,'condition for an aggregate or a group',34);

INSERT INTO answers(id,name,question_id) VALUES (126,'SORT',35);
INSERT INTO answers(id,name,question_id) VALUES (127,'ORDER BY',35);
INSERT INTO answers(id,name,question_id) VALUES (128,'ARRANGE',35);

INSERT INTO answers(id,name,question_id) VALUES (129,'INVERT',36);
INSERT INTO answers(id,name,question_id) VALUES (130,'INSERT',36);
INSERT INTO answers(id,name,question_id) VALUES (131,'UPDATE',36);

INSERT INTO answers(id,name,question_id) VALUES (132,'create a new table in the database',37);
INSERT INTO answers(id,name,question_id) VALUES (133,'modify an existing table in a database',37);
INSERT INTO answers(id,name,question_id) VALUES (134,'delete a table from the database',37);

INSERT INTO answers(id,name,question_id) VALUES (135,'answer135',38);
INSERT INTO answers(id,name,question_id) VALUES (136,'answer136',38);
INSERT INTO answers(id,name,question_id) VALUES (137,'answer137',38);
INSERT INTO answers(id,name,question_id) VALUES (138,'answer138',38);
INSERT INTO answers(id,name,question_id) VALUES (139,'answer139',39);
INSERT INTO answers(id,name,question_id) VALUES (140,'answer140',39);
INSERT INTO answers(id,name,question_id) VALUES (141,'answer141',40);
INSERT INTO answers(id,name,question_id) VALUES (142,'answer142',40);
INSERT INTO answers(id,name,question_id) VALUES (143,'answer143',40);
INSERT INTO answers(id,name,question_id) VALUES (144,'answer144',40);
INSERT INTO answers(id,name,question_id) VALUES (145,'answer145',41);
INSERT INTO answers(id,name,question_id) VALUES (146,'answer146',41);
INSERT INTO answers(id,name,question_id) VALUES (147,'answer147',41);
INSERT INTO answers(id,name,question_id) VALUES (148,'answer148',41);
INSERT INTO answers(id,name,question_id) VALUES (149,'answer149',42);
INSERT INTO answers(id,name,question_id) VALUES (150,'answer150',42);
INSERT INTO answers(id,name,question_id) VALUES (151,'answer151',42);
INSERT INTO answers(id,name,question_id) VALUES (152,'answer152',42);
INSERT INTO answers(id,name,question_id) VALUES (153,'answer153',43);
INSERT INTO answers(id,name,question_id) VALUES (154,'answer154',43);
INSERT INTO answers(id,name,question_id) VALUES (155,'answer155',43);
INSERT INTO answers(id,name,question_id) VALUES (156,'answer156',43);
INSERT INTO answers(id,name,question_id) VALUES (157,'answer157',44);
INSERT INTO answers(id,name,question_id) VALUES (158,'answer158',44);
INSERT INTO answers(id,name,question_id) VALUES (159,'answer159',44);
INSERT INTO answers(id,name,question_id) VALUES (160,'answer160',44);
INSERT INTO answers(id,name,question_id) VALUES (161,'answer161',45);
INSERT INTO answers(id,name,question_id) VALUES (162,'answer162',45);
INSERT INTO answers(id,name,question_id) VALUES (163,'answer163',45);
INSERT INTO answers(id,name,question_id) VALUES (164,'answer164',45);
INSERT INTO answers(id,name,question_id) VALUES (165,'answer165',46);
INSERT INTO answers(id,name,question_id) VALUES (166,'answer166',46);
INSERT INTO answers(id,name,question_id) VALUES (167,'answer167',47);
INSERT INTO answers(id,name,question_id) VALUES (168,'answer168',47);
INSERT INTO answers(id,name,question_id) VALUES (169,'answer169',47);
INSERT INTO answers(id,name,question_id) VALUES (170,'answer170',47);
INSERT INTO answers(id,name,question_id) VALUES (171,'answer171',48);
INSERT INTO answers(id,name,question_id) VALUES (172,'answer172',48);
INSERT INTO answers(id,name,question_id) VALUES (173,'answer173',49);
INSERT INTO answers(id,name,question_id) VALUES (174,'answer174',49);
INSERT INTO answers(id,name,question_id) VALUES (175,'answer175',50);
INSERT INTO answers(id,name,question_id) VALUES (176,'answer176',50);
INSERT INTO answers(id,name,question_id) VALUES (177,'answer177',50);
INSERT INTO answers(id,name,question_id) VALUES (178,'answer178',50);
INSERT INTO answers(id,name,question_id) VALUES (179,'answer179',51);
INSERT INTO answers(id,name,question_id) VALUES (180,'answer180',51);
INSERT INTO answers(id,name,question_id) VALUES (181,'answer181',51);
INSERT INTO answers(id,name,question_id) VALUES (182,'answer182',51);
INSERT INTO answers(id,name,question_id) VALUES (183,'answer183',52);
INSERT INTO answers(id,name,question_id) VALUES (184,'answer184',52);
INSERT INTO answers(id,name,question_id) VALUES (185,'answer185',52);
INSERT INTO answers(id,name,question_id) VALUES (186,'answer186',52);
INSERT INTO answers(id,name,question_id) VALUES (187,'answer187',53);
INSERT INTO answers(id,name,question_id) VALUES (188,'answer188',53);
INSERT INTO answers(id,name,question_id) VALUES (189,'answer189',53);
INSERT INTO answers(id,name,question_id) VALUES (190,'answer190',53);
INSERT INTO answers(id,name,question_id) VALUES (191,'answer191',54);
INSERT INTO answers(id,name,question_id) VALUES (192,'answer192',54);
INSERT INTO answers(id,name,question_id) VALUES (193,'answer193',55);
INSERT INTO answers(id,name,question_id) VALUES (194,'answer194',55);
INSERT INTO answers(id,name,question_id) VALUES (195,'answer195',56);
INSERT INTO answers(id,name,question_id) VALUES (196,'answer196',56);
INSERT INTO answers(id,name,question_id) VALUES (197,'answer197',56);
INSERT INTO answers(id,name,question_id) VALUES (198,'answer198',56);
INSERT INTO answers(id,name,question_id) VALUES (199,'answer199',57);
INSERT INTO answers(id,name,question_id) VALUES (200,'answer200',57);

INSERT INTO answers(id,name,question_id) VALUES (201,'answer201',58);
INSERT INTO answers(id,name,question_id) VALUES (202,'answer202',58);
INSERT INTO answers(id,name,question_id) VALUES (203,'answer203',58);
INSERT INTO answers(id,name,question_id) VALUES (204,'answer204',58);
INSERT INTO answers(id,name,question_id) VALUES (205,'answer205',59);
INSERT INTO answers(id,name,question_id) VALUES (206,'answer206',59);
INSERT INTO answers(id,name,question_id) VALUES (207,'answer207',59);
INSERT INTO answers(id,name,question_id) VALUES (208,'answer208',59);
INSERT INTO answers(id,name,question_id) VALUES (209,'answer209',60);
INSERT INTO answers(id,name,question_id) VALUES (210,'answer210',60);
INSERT INTO answers(id,name,question_id) VALUES (211,'answer211',61);
INSERT INTO answers(id,name,question_id) VALUES (212,'answer212',61);
INSERT INTO answers(id,name,question_id) VALUES (213,'answer213',61);
INSERT INTO answers(id,name,question_id) VALUES (214,'answer214',61);
INSERT INTO answers(id,name,question_id) VALUES (215,'answer215',62);
INSERT INTO answers(id,name,question_id) VALUES (216,'answer216',62);
INSERT INTO answers(id,name,question_id) VALUES (217,'answer217',63);
INSERT INTO answers(id,name,question_id) VALUES (218,'answer218',63);
INSERT INTO answers(id,name,question_id) VALUES (219,'answer219',64);
INSERT INTO answers(id,name,question_id) VALUES (220,'answer220',64);
INSERT INTO answers(id,name,question_id) VALUES (221,'answer221',64);
INSERT INTO answers(id,name,question_id) VALUES (222,'answer222',64);
INSERT INTO answers(id,name,question_id) VALUES (223,'answer223',65);
INSERT INTO answers(id,name,question_id) VALUES (224,'answer224',65);
INSERT INTO answers(id,name,question_id) VALUES (225,'answer225',66);
INSERT INTO answers(id,name,question_id) VALUES (226,'answer226',66);
INSERT INTO answers(id,name,question_id) VALUES (227,'answer227',66);
INSERT INTO answers(id,name,question_id) VALUES (228,'answer228',66);
INSERT INTO answers(id,name,question_id) VALUES (229,'answer229',67);
INSERT INTO answers(id,name,question_id) VALUES (230,'answer230',67);
INSERT INTO answers(id,name,question_id) VALUES (231,'answer231',68);
INSERT INTO answers(id,name,question_id) VALUES (232,'answer232',68);
INSERT INTO answers(id,name,question_id) VALUES (233,'answer233',68);
INSERT INTO answers(id,name,question_id) VALUES (234,'answer234',68);
INSERT INTO answers(id,name,question_id) VALUES (235,'answer235',69);
INSERT INTO answers(id,name,question_id) VALUES (236,'answer236',69);
INSERT INTO answers(id,name,question_id) VALUES (237,'answer237',69);
INSERT INTO answers(id,name,question_id) VALUES (238,'answer238',69);
INSERT INTO answers(id,name,question_id) VALUES (239,'answer239',70);
INSERT INTO answers(id,name,question_id) VALUES (240,'answer240',70);
INSERT INTO answers(id,name,question_id) VALUES (241,'answer241',71);
INSERT INTO answers(id,name,question_id) VALUES (242,'answer242',71);
INSERT INTO answers(id,name,question_id) VALUES (243,'answer243',71);
INSERT INTO answers(id,name,question_id) VALUES (244,'answer244',71);
INSERT INTO answers(id,name,question_id) VALUES (245,'answer245',72);
INSERT INTO answers(id,name,question_id) VALUES (246,'answer246',72);
INSERT INTO answers(id,name,question_id) VALUES (247,'answer247',73);
INSERT INTO answers(id,name,question_id) VALUES (248,'answer248',73);
INSERT INTO answers(id,name,question_id) VALUES (249,'answer249',74);
INSERT INTO answers(id,name,question_id) VALUES (250,'answer250',74);
INSERT INTO answers(id,name,question_id) VALUES (251,'answer251',74);
INSERT INTO answers(id,name,question_id) VALUES (252,'answer252',74);
INSERT INTO answers(id,name,question_id) VALUES (253,'answer253',75);
INSERT INTO answers(id,name,question_id) VALUES (254,'answer254',75);
INSERT INTO answers(id,name,question_id) VALUES (255,'answer255',75);
INSERT INTO answers(id,name,question_id) VALUES (256,'answer256',75);
INSERT INTO answers(id,name,question_id) VALUES (257,'answer257',76);
INSERT INTO answers(id,name,question_id) VALUES (258,'answer258',76);
INSERT INTO answers(id,name,question_id) VALUES (259,'answer259',76);
INSERT INTO answers(id,name,question_id) VALUES (260,'answer260',77);
INSERT INTO answers(id,name,question_id) VALUES (261,'answer261',77);
INSERT INTO answers(id,name,question_id) VALUES (262,'answer262',77);
INSERT INTO answers(id,name,question_id) VALUES (263,'answer263',77);
INSERT INTO answers(id,name,question_id) VALUES (264,'answer264',78);
INSERT INTO answers(id,name,question_id) VALUES (265,'answer265',78);
INSERT INTO answers(id,name,question_id) VALUES (266,'answer266',79);
INSERT INTO answers(id,name,question_id) VALUES (267,'answer267',79);
INSERT INTO answers(id,name,question_id) VALUES (268,'answer268',79);
INSERT INTO answers(id,name,question_id) VALUES (269,'answer269',79);
INSERT INTO answers(id,name,question_id) VALUES (270,'answer270',80);
INSERT INTO answers(id,name,question_id) VALUES (271,'answer271',80);
INSERT INTO answers(id,name,question_id) VALUES (272,'answer272',80);
INSERT INTO answers(id,name,question_id) VALUES (273,'answer273',80);
INSERT INTO answers(id,name,question_id) VALUES (274,'answer274',81);
INSERT INTO answers(id,name,question_id) VALUES (275,'answer275',81);
INSERT INTO answers(id,name,question_id) VALUES (276,'answer276',82);
INSERT INTO answers(id,name,question_id) VALUES (277,'answer277',82);
INSERT INTO answers(id,name,question_id) VALUES (278,'answer278',83);
INSERT INTO answers(id,name,question_id) VALUES (279,'answer279',83);
INSERT INTO answers(id,name,question_id) VALUES (280,'answer280',83);
INSERT INTO answers(id,name,question_id) VALUES (281,'answer281',83);
INSERT INTO answers(id,name,question_id) VALUES (282,'answer282',84);
INSERT INTO answers(id,name,question_id) VALUES (283,'answer283',84);
INSERT INTO answers(id,name,question_id) VALUES (284,'answer284',85);
INSERT INTO answers(id,name,question_id) VALUES (285,'answer285',85);
INSERT INTO answers(id,name,question_id) VALUES (286,'answer286',85);
INSERT INTO answers(id,name,question_id) VALUES (287,'answer287',85);
INSERT INTO answers(id,name,question_id) VALUES (288,'answer288',86);
INSERT INTO answers(id,name,question_id) VALUES (289,'answer289',86);
INSERT INTO answers(id,name,question_id) VALUES (290,'answer290',86);
INSERT INTO answers(id,name,question_id) VALUES (291,'answer291',87);
INSERT INTO answers(id,name,question_id) VALUES (292,'answer292',87);
INSERT INTO answers(id,name,question_id) VALUES (293,'answer293',87);
INSERT INTO answers(id,name,question_id) VALUES (294,'answer294',87);
INSERT INTO answers(id,name,question_id) VALUES (295,'answer295',88);
INSERT INTO answers(id,name,question_id) VALUES (296,'answer296',88);
INSERT INTO answers(id,name,question_id) VALUES (297,'answer297',89);
INSERT INTO answers(id,name,question_id) VALUES (298,'answer298',89);
INSERT INTO answers(id,name,question_id) VALUES (299,'answer299',90);
INSERT INTO answers(id,name,question_id) VALUES (300,'answer300',90);

INSERT INTO answers(id,name,question_id) VALUES (301,'answer301',91);
INSERT INTO answers(id,name,question_id) VALUES (302,'answer302',91);
INSERT INTO answers(id,name,question_id) VALUES (303,'answer303',91);
INSERT INTO answers(id,name,question_id) VALUES (304,'answer304',91);
INSERT INTO answers(id,name,question_id) VALUES (305,'answer305',92);
INSERT INTO answers(id,name,question_id) VALUES (306,'answer306',92);
INSERT INTO answers(id,name,question_id) VALUES (307,'answer307',92);
INSERT INTO answers(id,name,question_id) VALUES (308,'answer308',92);
INSERT INTO answers(id,name,question_id) VALUES (309,'answer309',93);
INSERT INTO answers(id,name,question_id) VALUES (310,'answer310',93);
INSERT INTO answers(id,name,question_id) VALUES (311,'answer311',93);
INSERT INTO answers(id,name,question_id) VALUES (312,'answer312',93);
INSERT INTO answers(id,name,question_id) VALUES (313,'answer313',94);
INSERT INTO answers(id,name,question_id) VALUES (314,'answer314',94);
INSERT INTO answers(id,name,question_id) VALUES (315,'answer315',94);
INSERT INTO answers(id,name,question_id) VALUES (316,'answer316',95);
INSERT INTO answers(id,name,question_id) VALUES (317,'answer317',95);
INSERT INTO answers(id,name,question_id) VALUES (318,'answer318',95);
INSERT INTO answers(id,name,question_id) VALUES (319,'answer319',96);
INSERT INTO answers(id,name,question_id) VALUES (320,'answer320',96);
INSERT INTO answers(id,name,question_id) VALUES (321,'answer321',96);
INSERT INTO answers(id,name,question_id) VALUES (322,'answer322',96);
INSERT INTO answers(id,name,question_id) VALUES (323,'answer323',97);
INSERT INTO answers(id,name,question_id) VALUES (324,'answer324',97);
INSERT INTO answers(id,name,question_id) VALUES (325,'answer325',97);
INSERT INTO answers(id,name,question_id) VALUES (326,'answer326',97);
INSERT INTO answers(id,name,question_id) VALUES (327,'answer327',98);
INSERT INTO answers(id,name,question_id) VALUES (328,'answer328',98);
INSERT INTO answers(id,name,question_id) VALUES (329,'answer329',99);
INSERT INTO answers(id,name,question_id) VALUES (330,'answer330',99);
INSERT INTO answers(id,name,question_id) VALUES (331,'answer331',100);
INSERT INTO answers(id,name,question_id) VALUES (332,'answer332',100);
INSERT INTO answers(id,name,question_id) VALUES (333,'answer333',100);
INSERT INTO answers(id,name,question_id) VALUES (334,'answer334',100);
INSERT INTO answers(id,name,question_id) VALUES (335,'answer335',100);
INSERT INTO answers(id,name,question_id) VALUES (336,'answer336',101);
INSERT INTO answers(id,name,question_id) VALUES (337,'answer337',101);
INSERT INTO answers(id,name,question_id) VALUES (338,'answer338',101);
INSERT INTO answers(id,name,question_id) VALUES (339,'answer339',101);
INSERT INTO answers(id,name,question_id) VALUES (340,'answer340',102);
INSERT INTO answers(id,name,question_id) VALUES (341,'answer341',102);
INSERT INTO answers(id,name,question_id) VALUES (342,'answer342',103);
INSERT INTO answers(id,name,question_id) VALUES (343,'answer343',103);
INSERT INTO answers(id,name,question_id) VALUES (344,'answer344',104);
INSERT INTO answers(id,name,question_id) VALUES (345,'answer345',104);
INSERT INTO answers(id,name,question_id) VALUES (346,'answer346',104);
INSERT INTO answers(id,name,question_id) VALUES (347,'answer347',105);
INSERT INTO answers(id,name,question_id) VALUES (348,'answer348',105);
INSERT INTO answers(id,name,question_id) VALUES (349,'answer349',105);
INSERT INTO answers(id,name,question_id) VALUES (350,'answer350',105);
INSERT INTO answers(id,name,question_id) VALUES (351,'answer351',106);
INSERT INTO answers(id,name,question_id) VALUES (352,'answer352',106);
INSERT INTO answers(id,name,question_id) VALUES (353,'answer353',106);
INSERT INTO answers(id,name,question_id) VALUES (354,'answer354',106);
INSERT INTO answers(id,name,question_id) VALUES (355,'answer355',107);
INSERT INTO answers(id,name,question_id) VALUES (356,'answer356',107);
INSERT INTO answers(id,name,question_id) VALUES (357,'answer357',108);
INSERT INTO answers(id,name,question_id) VALUES (358,'answer358',108);
INSERT INTO answers(id,name,question_id) VALUES (359,'answer359',108);
INSERT INTO answers(id,name,question_id) VALUES (360,'answer360',108);
INSERT INTO answers(id,name,question_id) VALUES (361,'answer361',109);
INSERT INTO answers(id,name,question_id) VALUES (362,'answer362',109);
INSERT INTO answers(id,name,question_id) VALUES (363,'answer363',109);
INSERT INTO answers(id,name,question_id) VALUES (364,'answer364',110);
INSERT INTO answers(id,name,question_id) VALUES (365,'answer365',110);
INSERT INTO answers(id,name,question_id) VALUES (366,'answer366',110);
INSERT INTO answers(id,name,question_id) VALUES (367,'answer367',110);
INSERT INTO answers(id,name,question_id) VALUES (368,'answer368',111);
INSERT INTO answers(id,name,question_id) VALUES (369,'answer369',111);
INSERT INTO answers(id,name,question_id) VALUES (370,'answer370',112);
INSERT INTO answers(id,name,question_id) VALUES (371,'answer371',112);
INSERT INTO answers(id,name,question_id) VALUES (372,'answer372',112);
INSERT INTO answers(id,name,question_id) VALUES (373,'answer373',112);
INSERT INTO answers(id,name,question_id) VALUES (374,'answer374',112);
INSERT INTO answers(id,name,question_id) VALUES (375,'answer375',113);
INSERT INTO answers(id,name,question_id) VALUES (376,'answer376',113);
INSERT INTO answers(id,name,question_id) VALUES (377,'answer377',113);
INSERT INTO answers(id,name,question_id) VALUES (378,'answer378',114);
INSERT INTO answers(id,name,question_id) VALUES (379,'answer379',114);
INSERT INTO answers(id,name,question_id) VALUES (380,'answer380',115);
INSERT INTO answers(id,name,question_id) VALUES (381,'answer381',115);
INSERT INTO answers(id,name,question_id) VALUES (382,'answer382',115);
INSERT INTO answers(id,name,question_id) VALUES (383,'answer383',116);
INSERT INTO answers(id,name,question_id) VALUES (384,'answer384',116);
INSERT INTO answers(id,name,question_id) VALUES (385,'answer385',116);
INSERT INTO answers(id,name,question_id) VALUES (386,'answer386',116);
INSERT INTO answers(id,name,question_id) VALUES (387,'answer387',117);
INSERT INTO answers(id,name,question_id) VALUES (388,'answer388',117);
INSERT INTO answers(id,name,question_id) VALUES (389,'answer389',117);
INSERT INTO answers(id,name,question_id) VALUES (390,'answer390',117);
INSERT INTO answers(id,name,question_id) VALUES (391,'answer391',118);
INSERT INTO answers(id,name,question_id) VALUES (392,'answer392',118);
INSERT INTO answers(id,name,question_id) VALUES (393,'answer393',118);
INSERT INTO answers(id,name,question_id) VALUES (394,'answer394',118);
INSERT INTO answers(id,name,question_id) VALUES (395,'answer395',119);
INSERT INTO answers(id,name,question_id) VALUES (396,'answer396',119);
INSERT INTO answers(id,name,question_id) VALUES (397,'answer397',119);
INSERT INTO answers(id,name,question_id) VALUES (398,'answer398',119);
INSERT INTO answers(id,name,question_id) VALUES (399,'answer399',120);
INSERT INTO answers(id,name,question_id) VALUES (400,'answer400',120);


INSERT INTO answers(id,name,question_id) VALUES (401,'answer401',121);
INSERT INTO answers(id,name,question_id) VALUES (402,'answer402',121);
INSERT INTO answers(id,name,question_id) VALUES (403,'answer403',121);
INSERT INTO answers(id,name,question_id) VALUES (404,'answer404',121);
INSERT INTO answers(id,name,question_id) VALUES (405,'answer405',121);
INSERT INTO answers(id,name,question_id) VALUES (406,'answer406',122);
INSERT INTO answers(id,name,question_id) VALUES (407,'answer407',122);
INSERT INTO answers(id,name,question_id) VALUES (408,'answer408',122);
INSERT INTO answers(id,name,question_id) VALUES (409,'answer409',122);
INSERT INTO answers(id,name,question_id) VALUES (410,'answer410',123);
INSERT INTO answers(id,name,question_id) VALUES (411,'answer411',123);
INSERT INTO answers(id,name,question_id) VALUES (412,'answer412',123);
INSERT INTO answers(id,name,question_id) VALUES (413,'answer413',123);
INSERT INTO answers(id,name,question_id) VALUES (414,'answer414',124);
INSERT INTO answers(id,name,question_id) VALUES (415,'answer415',124);
INSERT INTO answers(id,name,question_id) VALUES (416,'answer416',125);
INSERT INTO answers(id,name,question_id) VALUES (417,'answer417',125);
INSERT INTO answers(id,name,question_id) VALUES (418,'answer418',125);
INSERT INTO answers(id,name,question_id) VALUES (419,'answer419',126);
INSERT INTO answers(id,name,question_id) VALUES (420,'answer420',126);
INSERT INTO answers(id,name,question_id) VALUES (421,'answer421',126);
INSERT INTO answers(id,name,question_id) VALUES (422,'answer422',126);
INSERT INTO answers(id,name,question_id) VALUES (423,'answer423',127);
INSERT INTO answers(id,name,question_id) VALUES (424,'answer424',127);
INSERT INTO answers(id,name,question_id) VALUES (425,'answer425',127);
INSERT INTO answers(id,name,question_id) VALUES (426,'answer426',127);
INSERT INTO answers(id,name,question_id) VALUES (427,'answer427',128);
INSERT INTO answers(id,name,question_id) VALUES (428,'answer428',128);
INSERT INTO answers(id,name,question_id) VALUES (429,'answer429',129);
INSERT INTO answers(id,name,question_id) VALUES (430,'answer430',129);
INSERT INTO answers(id,name,question_id) VALUES (431,'answer431',129);
INSERT INTO answers(id,name,question_id) VALUES (432,'answer432',129);
INSERT INTO answers(id,name,question_id) VALUES (433,'answer433',130);
INSERT INTO answers(id,name,question_id) VALUES (434,'answer434',130);
INSERT INTO answers(id,name,question_id) VALUES (435,'answer435',130);
INSERT INTO answers(id,name,question_id) VALUES (436,'answer436',131);
INSERT INTO answers(id,name,question_id) VALUES (437,'answer437',131);
INSERT INTO answers(id,name,question_id) VALUES (438,'answer438',131);
INSERT INTO answers(id,name,question_id) VALUES (439,'answer439',131);
INSERT INTO answers(id,name,question_id) VALUES (440,'answer440',132);
INSERT INTO answers(id,name,question_id) VALUES (441,'answer441',132);
INSERT INTO answers(id,name,question_id) VALUES (442,'answer442',133);
INSERT INTO answers(id,name,question_id) VALUES (443,'answer443',133);
INSERT INTO answers(id,name,question_id) VALUES (444,'answer444',134);
INSERT INTO answers(id,name,question_id) VALUES (445,'answer445',134);
INSERT INTO answers(id,name,question_id) VALUES (446,'answer446',134);
INSERT INTO answers(id,name,question_id) VALUES (447,'answer447',135);
INSERT INTO answers(id,name,question_id) VALUES (448,'answer448',135);
INSERT INTO answers(id,name,question_id) VALUES (449,'answer449',135);
INSERT INTO answers(id,name,question_id) VALUES (450,'answer450',135);
INSERT INTO answers(id,name,question_id) VALUES (451,'answer451',136);
INSERT INTO answers(id,name,question_id) VALUES (452,'answer452',136);
INSERT INTO answers(id,name,question_id) VALUES (453,'answer453',136);
INSERT INTO answers(id,name,question_id) VALUES (454,'answer454',136);
INSERT INTO answers(id,name,question_id) VALUES (455,'answer455',137);
INSERT INTO answers(id,name,question_id) VALUES (456,'answer456',137);
INSERT INTO answers(id,name,question_id) VALUES (457,'answer457',138);
INSERT INTO answers(id,name,question_id) VALUES (458,'answer458',138);
INSERT INTO answers(id,name,question_id) VALUES (459,'answer459',138);
INSERT INTO answers(id,name,question_id) VALUES (460,'answer460',138);
INSERT INTO answers(id,name,question_id) VALUES (461,'answer461',139);
INSERT INTO answers(id,name,question_id) VALUES (462,'answer462',139);
INSERT INTO answers(id,name,question_id) VALUES (463,'answer463',139);
INSERT INTO answers(id,name,question_id) VALUES (464,'answer464',140);
INSERT INTO answers(id,name,question_id) VALUES (465,'answer465',140);
INSERT INTO answers(id,name,question_id) VALUES (466,'answer466',140);
INSERT INTO answers(id,name,question_id) VALUES (467,'answer467',140);
INSERT INTO answers(id,name,question_id) VALUES (468,'answer468',141);
INSERT INTO answers(id,name,question_id) VALUES (469,'answer469',141);
INSERT INTO answers(id,name,question_id) VALUES (470,'answer470',142);
INSERT INTO answers(id,name,question_id) VALUES (471,'answer471',142);
INSERT INTO answers(id,name,question_id) VALUES (472,'answer472',142);
INSERT INTO answers(id,name,question_id) VALUES (473,'answer473',142);
INSERT INTO answers(id,name,question_id) VALUES (474,'answer474',142);
INSERT INTO answers(id,name,question_id) VALUES (475,'answer475',143);
INSERT INTO answers(id,name,question_id) VALUES (476,'answer476',143);
INSERT INTO answers(id,name,question_id) VALUES (477,'answer477',143);
INSERT INTO answers(id,name,question_id) VALUES (478,'answer478',144);
INSERT INTO answers(id,name,question_id) VALUES (479,'answer479',144);
INSERT INTO answers(id,name,question_id) VALUES (480,'answer480',145);
INSERT INTO answers(id,name,question_id) VALUES (481,'answer481',145);
INSERT INTO answers(id,name,question_id) VALUES (482,'answer482',145);
INSERT INTO answers(id,name,question_id) VALUES (483,'answer483',146);
INSERT INTO answers(id,name,question_id) VALUES (484,'answer484',146);
INSERT INTO answers(id,name,question_id) VALUES (485,'answer485',146);
INSERT INTO answers(id,name,question_id) VALUES (486,'answer486',146);
INSERT INTO answers(id,name,question_id) VALUES (487,'answer487',147);
INSERT INTO answers(id,name,question_id) VALUES (488,'answer488',147);
INSERT INTO answers(id,name,question_id) VALUES (489,'answer489',147);
INSERT INTO answers(id,name,question_id) VALUES (490,'answer490',147);
INSERT INTO answers(id,name,question_id) VALUES (491,'answer491',148);
INSERT INTO answers(id,name,question_id) VALUES (492,'answer492',148);
INSERT INTO answers(id,name,question_id) VALUES (493,'answer493',148);
INSERT INTO answers(id,name,question_id) VALUES (494,'answer494',148);
INSERT INTO answers(id,name,question_id) VALUES (495,'answer495',149);
INSERT INTO answers(id,name,question_id) VALUES (496,'answer496',149);
INSERT INTO answers(id,name,question_id) VALUES (497,'answer497',149);
INSERT INTO answers(id,name,question_id) VALUES (498,'answer498',149);
INSERT INTO answers(id,name,question_id) VALUES (499,'answer499',150);
INSERT INTO answers(id,name,question_id) VALUES (500,'answer500',150);

INSERT INTO answers(id,name,question_id) VALUES (501,'answer501',151);
INSERT INTO answers(id,name,question_id) VALUES (502,'answer502',151);
INSERT INTO answers(id,name,question_id) VALUES (503,'answer503',151);
INSERT INTO answers(id,name,question_id) VALUES (504,'answer504',151);
INSERT INTO answers(id,name,question_id) VALUES (505,'answer505',151);
INSERT INTO answers(id,name,question_id) VALUES (506,'answer506',152);
INSERT INTO answers(id,name,question_id) VALUES (507,'answer507',152);
INSERT INTO answers(id,name,question_id) VALUES (508,'answer508',152);
INSERT INTO answers(id,name,question_id) VALUES (509,'answer509',152);
INSERT INTO answers(id,name,question_id) VALUES (510,'answer510',153);
INSERT INTO answers(id,name,question_id) VALUES (511,'answer511',153);
INSERT INTO answers(id,name,question_id) VALUES (512,'answer512',153);
INSERT INTO answers(id,name,question_id) VALUES (513,'answer513',153);
INSERT INTO answers(id,name,question_id) VALUES (514,'answer514',154);
INSERT INTO answers(id,name,question_id) VALUES (515,'answer515',154);
INSERT INTO answers(id,name,question_id) VALUES (516,'answer516',155);
INSERT INTO answers(id,name,question_id) VALUES (517,'answer517',155);
INSERT INTO answers(id,name,question_id) VALUES (518,'answer518',155);
INSERT INTO answers(id,name,question_id) VALUES (519,'answer519',156);
INSERT INTO answers(id,name,question_id) VALUES (520,'answer520',156);
INSERT INTO answers(id,name,question_id) VALUES (521,'answer521',156);
INSERT INTO answers(id,name,question_id) VALUES (522,'answer522',156);

INSERT INTO answers(id,name,question_id) VALUES (536,'answer536',161);
INSERT INTO answers(id,name,question_id) VALUES (537,'answer537',161);
INSERT INTO answers(id,name,question_id) VALUES (538,'answer538',161);
INSERT INTO answers(id,name,question_id) VALUES (539,'answer539',161);
INSERT INTO answers(id,name,question_id) VALUES (540,'answer540',162);
INSERT INTO answers(id,name,question_id) VALUES (541,'answer541',162);
INSERT INTO answers(id,name,question_id) VALUES (542,'answer542',163);
INSERT INTO answers(id,name,question_id) VALUES (543,'answer543',163);
INSERT INTO answers(id,name,question_id) VALUES (544,'answer544',164);
INSERT INTO answers(id,name,question_id) VALUES (545,'answer545',164);
INSERT INTO answers(id,name,question_id) VALUES (546,'answer546',164);
INSERT INTO answers(id,name,question_id) VALUES (547,'answer547',165);
INSERT INTO answers(id,name,question_id) VALUES (548,'answer548',165);
INSERT INTO answers(id,name,question_id) VALUES (549,'answer549',165);
INSERT INTO answers(id,name,question_id) VALUES (550,'answer550',165);
INSERT INTO answers(id,name,question_id) VALUES (551,'answer551',166);
INSERT INTO answers(id,name,question_id) VALUES (552,'answer552',166);
INSERT INTO answers(id,name,question_id) VALUES (553,'answer553',166);
INSERT INTO answers(id,name,question_id) VALUES (554,'answer554',166);
INSERT INTO answers(id,name,question_id) VALUES (555,'answer555',167);
INSERT INTO answers(id,name,question_id) VALUES (556,'answer556',167);
INSERT INTO answers(id,name,question_id) VALUES (557,'answer557',168);
INSERT INTO answers(id,name,question_id) VALUES (558,'answer558',168);
INSERT INTO answers(id,name,question_id) VALUES (559,'answer559',168);
INSERT INTO answers(id,name,question_id) VALUES (560,'answer560',168);
INSERT INTO answers(id,name,question_id) VALUES (561,'answer561',169);
INSERT INTO answers(id,name,question_id) VALUES (562,'answer562',169);
INSERT INTO answers(id,name,question_id) VALUES (563,'answer563',169);
INSERT INTO answers(id,name,question_id) VALUES (564,'answer564',170);
INSERT INTO answers(id,name,question_id) VALUES (565,'answer565',170);
INSERT INTO answers(id,name,question_id) VALUES (566,'answer566',170);
INSERT INTO answers(id,name,question_id) VALUES (567,'answer567',170);
INSERT INTO answers(id,name,question_id) VALUES (568,'answer568',171);
INSERT INTO answers(id,name,question_id) VALUES (569,'answer569',171);
INSERT INTO answers(id,name,question_id) VALUES (570,'answer570',172);
INSERT INTO answers(id,name,question_id) VALUES (571,'answer571',172);
INSERT INTO answers(id,name,question_id) VALUES (572,'answer572',172);
INSERT INTO answers(id,name,question_id) VALUES (573,'answer573',172);
INSERT INTO answers(id,name,question_id) VALUES (574,'answer574',172);
INSERT INTO answers(id,name,question_id) VALUES (575,'answer575',173);
INSERT INTO answers(id,name,question_id) VALUES (576,'answer576',173);
INSERT INTO answers(id,name,question_id) VALUES (577,'answer577',173);
INSERT INTO answers(id,name,question_id) VALUES (578,'answer578',174);
INSERT INTO answers(id,name,question_id) VALUES (579,'answer579',174);
INSERT INTO answers(id,name,question_id) VALUES (580,'answer580',175);
INSERT INTO answers(id,name,question_id) VALUES (581,'answer581',175);
INSERT INTO answers(id,name,question_id) VALUES (582,'answer582',175);
INSERT INTO answers(id,name,question_id) VALUES (583,'answer583',176);
INSERT INTO answers(id,name,question_id) VALUES (584,'answer584',176);
INSERT INTO answers(id,name,question_id) VALUES (585,'answer585',176);
INSERT INTO answers(id,name,question_id) VALUES (586,'answer586',176);
INSERT INTO answers(id,name,question_id) VALUES (587,'answer587',177);
INSERT INTO answers(id,name,question_id) VALUES (588,'answer588',177);
INSERT INTO answers(id,name,question_id) VALUES (589,'answer589',177);
INSERT INTO answers(id,name,question_id) VALUES (590,'answer590',177);
INSERT INTO answers(id,name,question_id) VALUES (591,'answer591',178);
INSERT INTO answers(id,name,question_id) VALUES (592,'answer592',178);
INSERT INTO answers(id,name,question_id) VALUES (593,'answer593',178);
INSERT INTO answers(id,name,question_id) VALUES (594,'answer594',178);
INSERT INTO answers(id,name,question_id) VALUES (595,'answer595',179);
INSERT INTO answers(id,name,question_id) VALUES (596,'answer596',179);
INSERT INTO answers(id,name,question_id) VALUES (597,'answer597',179);
INSERT INTO answers(id,name,question_id) VALUES (598,'answer598',179);
INSERT INTO answers(id,name,question_id) VALUES (599,'answer599',180);
INSERT INTO answers(id,name,question_id) VALUES (600,'answer600',180);


INSERT INTO answers(id,name,question_id) VALUES (601,'answer601',181);
INSERT INTO answers(id,name,question_id) VALUES (602,'answer602',181);
INSERT INTO answers(id,name,question_id) VALUES (603,'answer603',181);
INSERT INTO answers(id,name,question_id) VALUES (604,'answer604',181);
INSERT INTO answers(id,name,question_id) VALUES (605,'answer605',181);
INSERT INTO answers(id,name,question_id) VALUES (606,'answer606',182);
INSERT INTO answers(id,name,question_id) VALUES (607,'answer607',182);
INSERT INTO answers(id,name,question_id) VALUES (608,'answer608',182);
INSERT INTO answers(id,name,question_id) VALUES (609,'answer609',182);
INSERT INTO answers(id,name,question_id) VALUES (610,'answer610',183);
INSERT INTO answers(id,name,question_id) VALUES (611,'answer611',183);
INSERT INTO answers(id,name,question_id) VALUES (612,'answer612',183);
INSERT INTO answers(id,name,question_id) VALUES (613,'answer613',183);
INSERT INTO answers(id,name,question_id) VALUES (614,'answer614',184);
INSERT INTO answers(id,name,question_id) VALUES (615,'answer615',184);
INSERT INTO answers(id,name,question_id) VALUES (616,'answer616',185);
INSERT INTO answers(id,name,question_id) VALUES (617,'answer617',185);
INSERT INTO answers(id,name,question_id) VALUES (618,'answer618',185);
INSERT INTO answers(id,name,question_id) VALUES (619,'answer619',185);


/* insert correct answers */

INSERT INTO correct_answers(id,answer_id,question_id) VALUES (1,2,1);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (2,7,2);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (3,11,3);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (4,17,4);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (5,19,5);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (6,23,6);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (7,24,7);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (8,29,8);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (9,35,9);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (10,40,10);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (11,42,11);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (12,46,12);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (13,48,13);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (14,50,14);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (15,56,15);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (16,58,16);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (17,61,17);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (18,68,18);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (19,69,19);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (20,73,20);

/* updates */
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (21,75,21);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (22,78,22);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (23,83,23);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (24,85,24);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (25,89,25);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (26,94,26);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (27,99,27);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (28,103,28);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (29,104,29);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (30,108,30);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (31,113,31);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (32,114,32);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (33,121,33);


INSERT INTO correct_answers(id,answer_id,question_id) VALUES (34,125,34);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (35,126,35);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (36,129,36);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (37,134,37);

INSERT INTO correct_answers(id,answer_id,question_id) VALUES (38,136,38);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (39,140,39);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (40,143,40);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (41,147,41);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (42,152,42);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (43,155,43);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (44,159,44);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (45,161,45);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (46,166,46);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (47,170,47);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (48,172,48);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (49,174,49);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (50,177,50);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (51,181,51);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (52,184,52);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (53,190,53);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (54,191,54);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (55,193,55);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (56,195,56);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (57,199,57);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (58,202,58);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (59,206,59);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (60,209,60);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (61,213,61);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (62,216,62);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (63,217,63);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (64,222,64);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (65,224,65);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (66,227,66);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (67,230,67);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (68,232,68);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (69,236,69);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (70,240,70);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (71,244,71);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (72,245,72);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (73,248,73);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (74,250,74);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (75,256,75);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (76,258,76);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (77,260,77);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (78,264,78);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (79,269,79);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (80,273,80);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (81,274,81);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (82,275,82);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (83,281,83);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (84,282,84);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (85,286,85);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (86,290,86);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (87,294,87);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (88,296,88);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (89,297,89);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (90,299,90);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (91,304,91);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (92,307,92);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (93,309,93);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (94,313,94);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (95,318,95);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (96,322,96);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (97,325,97);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (98,328,98);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (99,330,99);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (100,334,100);

INSERT INTO correct_answers(id,answer_id,question_id) VALUES (101,339,101);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (102,341,102);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (103,343,103);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (104,354,104);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (105,350,105);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (106,353,106);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (107,355,107);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (108,357,108);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (109,361,109);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (110,364,110);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (111,369,111);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (112,373,112);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (113,377,113);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (114,379,114);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (115,382,115);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (116,384,116);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (117,390,117);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (118,391,118);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (119,396,119);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (120,400,120);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (121,404,121);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (122,407,122);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (123,410,123);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (124,415,124);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (125,418,125);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (126,421,126);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (127,426,127);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (128,427,128);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (129,431,129);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (130,435,130);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (131,437,131);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (132,440,132);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (133,443,133);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (134,444,134);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (135,450,135);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (136,452,136);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (137,456,137);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (138,459,138);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (139,462,139);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (140,466,140);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (141,469,141);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (142,473,142);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (143,475,143);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (144,478,144);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (145,481,145);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (146,483,146);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (147,489,147);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (148,492,148);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (149,497,149);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (150,499,150);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (151,504,151);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (152,508,152);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (153,511,153);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (154,515,154);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (155,516,155);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (156,521,156);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (161,538,161);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (162,540,162);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (163,542,163);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (164,545,164);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (165,550,165);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (166,551,166);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (167,556,167);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (168,559,168);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (169,563,169);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (170,566,170);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (171,568,171);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (172,571,172);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (173,576,173);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (174,578,174);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (175,580,175);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (176,585,176);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (177,589,177);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (178,592,178);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (179,596,179);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (180,600,180);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (181,604,181);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (182,609,182);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (183,610,183);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (184,615,184);
INSERT INTO correct_answers(id,answer_id,question_id) VALUES (185,618,185);
