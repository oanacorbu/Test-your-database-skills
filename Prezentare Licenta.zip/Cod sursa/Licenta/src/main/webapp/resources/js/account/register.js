$(document).ready(function() {
	$("#registerError").hide();
});

function validateAndCreateAccount(url){

    $("#registerName").css('border-color','#D8D8D8');
	$("#registerSurname").css('border-color','#D8D8D8');
	$("#registerEmail").css('border-color','#D8D8D8');
	$("#registerPassword").css('border-color','#D8D8D8');
	$("#registerConfirmPas").css('border-color','#D8D8D8');

    $("#errorName").hide();
    $("#errorSurname").hide();
    $("#errorPassword").hide();
    $("#errorConfirmPas").hide();
    $("#errorEmail").hide();

    var studentCredentials = registerValidation();
     if ( studentCredentials != false) {
    	 registerNewStudent(studentCredentials,url);
    }
}

function registerValidation(){
	
	var register = true;
	var password;
	var confirmPassword;
  
    // validation for name field
    if ( $("#registerName").val().trim().length == 0 ){
    	$("#errorName").text("Name field is required ");
		$("#errorName").show();
		register = false;
    }
	else if ( /^[a-z A-Z]+$/.test($("#registerName").val()) === false){
		$("#errorName").text("Name field must contain only letters");
		$("#errorName").show();
		register = false;
	}
    else if ( $("#registerName").val().length > 25) {
    	$("#errorName").text("The name may contain only 25 characters ");
		$("#errorName").show();
		register = false;
    }

    // validation for surname field
    if ( $("#registerSurname").val().trim().length == 0 ){
    	$("#errorSurname").text("Surname field is required ");
		$("#errorSurname").show();
		register = false;
    }
    else if ( /^[a-z A-Z]+$/.test($("#registerSurname").val()) === false){
		$("#errorSurname").text("Surname field must contain only letters");
		$("#errorSurname").show();
		register = false;
	}
    else if ( $("#registerSurname").val().length > 25) {
    	$("#errorSurname").text("Surname may contain only 25 characters ");
		$("#errorSurname").show();
		register = false;
    }

    // validation for email field
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    if (pattern.test($("#registerEmail").val()) == false) {
    	$("#errorEmail").text("Email is not properly formatted ");
		$("#errorEmail").show();
    	register = false;
    }

    // validation for password field
    if ( $("#registerPassword").val().trim().length == 0 ){
    	$("#errorPassword").text("Password field is required ");
		$("#errorPassword").show();
		register = false;
    }
    else if ( $("#registerPassword").val().length < 6) {
    	$("#errorPassword").text("Password may contain at least 6 characters ");
		$("#errorPassword").show();
		register = false;
    }

    // validation for confirm password field
    if ( $("#registerConfirmPas").val().trim().length == 0 ){
    	$("#errorConfirmPas").text("Confirm password field is required ");
		$("#errorConfirmPas").show();
		register = false;
    }

    password = $("#registerPassword").val();
    confirmPassword = $("#registerConfirmPas").val();

    if ( password != confirmPassword && confirmPassword.length !=0 ){
    	$("#errorConfirmPas").text("Those passwords must be the same");
		$("#errorConfirmPas").show();
		register = false;
    }

    if ( register == true ){
        var studentCredentials = {
            name : $("#registerName").val(),
            surname : $("#registerSurname").val(),
            email : $("#registerEmail").val(),
            password : $("#registerPassword").val()
        };

        return studentCredentials;
    }

    else return false;
}

function registerNewStudent(studentData,url){
    $.ajax({
        url: url + "/registerNewStudent",
        type: 'POST',
        beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
        		$('meta[name="_csrf_token"]').attr('content'))},
        data: studentData,
        success: function(data){
        	if(data.response == true){
        		window.location.href= url + "/login";
        	}
        	else{
        		$("#registerError").html("Email already exists");
        		$("#registerError").show();
        	}
        },
        error: function(e){
            console.log(e);
        }
    });
}
