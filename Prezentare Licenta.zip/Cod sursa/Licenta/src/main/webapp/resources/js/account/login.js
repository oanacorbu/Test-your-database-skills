$(document).ready(function() {
      $("#finishLogin").on('click',function(){
//          $("#loginForm").hide();

          $("#loginEmail").val('');
          $("#loginPassword").val('');
          $("#passwordError").hide();
          $("#emailError").hide();

//          $("#registerForm").show();
//          $("#registerForm").css("border-radius","5%");
      });
      
});
//function displayLoginContent(){
//    
//    $("#registerForm").hide();
//    
//    $("#registerName").val('');
//    $("#registerSurname").val('');
//    $("#registerEmail").val('');
//    $("#registerPassword").val('');
//    $("#registerConfirmPas").val('');
//
//    $("#errorName").hide();
//    $("#errorSurname").hide();
//    $("#errorPassword").hide();
//    $("#errorConfirmPas").hide();
//    $("#errorEmail").hide();
//
//    $("#loginForm").show();
//    $("#loginForm").css("border-radius","5%");
//
//    $("#passwordError").hide();
//    $("#emailError").hide();
//
//    $("#loginEmail").val('');
//    $("#loginPassword").val('');
//
//}

function validateAndLogin(){
    $("#loginEmail").css('border-color','#D8D8D8');
    $("#loginPassword").css('border-color','#D8D8D8');
  
    $("#passwordError").hide();
    $("#emailError").hide();

    var studentCredentials = loginValidation();
    if ( studentCredentials != false) {
        loginToApp(studentCredentials);
    }
}

function loginValidation(){

    var login = true;

    // email validation
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    
    if ( $("#loginEmail").val().trim().length == 0 ){
        $("#emailError").text("Email field is required ");
        $("#emailError").show();
        login = false;
    }

    else if (pattern.test($("#loginEmail").val()) == false) {
        $("#emailError").text("Email is not properly formatted ");
        $("#emailError").show();
        login = false;
    }

     // validation for password field
    if ( $("#loginPassword").val().trim().length == 0 ){
        $("#passwordError").text("Password field is required ");
        $("#passwordError").show();
        login = false;
    }
    else if ( $("#loginPassword").val().length < 6) {
        $("#passwordError").text("Password may contain at least 6 characters ");
        $("#passwordError").show();
        login = false;
    }

    if ( login == true) {
        var studentCredentials = {
            email : $("#loginEmail").val(),
            password : $("#loginPassword").val()
        };

        return studentCredentials;
    }
    else return false;
}

function loginToApp(studentCredentials){

     $.ajax({
        url:'/PathOfExile/login/loginUserToApp',
        type: 'POST',
        data: studentCredentials,
        success: function(data){
           if ( data == "0" ){
                $("#loginEmail").val('');
                $("#loginPassword").val('');

                $("#passwordError").show();
                $("#passwordError").text("Please try again, these credentials doesn`t exist");
           }
           else if ( data == "2" ){
                $("#passwordError").show();
                $("#passwordError").text("The password is incorrect");
           }
           else {
                
                console.log("You have successfully logged in " + data);
                window.location = '/PathOfExile/main';
           }
        },
        error: function(){
            console.log("Failed to login");
        }
    });
    
}