	var testResults;
	
	function showCompleteChart(url){
		$('#chartContainer').modal('show');
		$('.modal-backdrop').removeClass('in');
		$('.modal-backdrop').addClass('out');
		
		var studentsNames = [];
		var obtainedScores = [];
		
		$.ajax({
			url : url + "/showAllTestResults",
			type : 'GET',
			async : false,
			beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
	        		$('meta[name="_csrf_token"]').attr('content'))},
	        success : function(data){
	        	testResults = data;
	        },
	        error : function(e){
	        	console.log(e);
	        }
		});
		
		for ( var contor = 0; contor < testResults.length; contor++){
			studentsNames.push(testResults[contor].lastName + " " + testResults[contor].firstName);
			obtainedScores.push(testResults[contor].obtainedScore);
		}
		
		  $('#high-chart-container').highcharts({
			    chart: {
		            width : $( window ).width() * 0.45,
		            height : $( window ).height() * 0.40,
		            options3d: {
		                enabled: true,
		                alpha: 5,
		                beta: 10,
		                depth: 90
		            }
		        },
		        title: {
		            text: 'Complete situation',
		            x: -20 //center
		        },
		        xAxis: {
		            categories: studentsNames
		        },
		        yAxis: {
		            title: {
		                text: 'Score'
		            },
		            plotLines: [{
		                value: 0,
		                width: 1,
		                color: '#808080'
		            }]
		        },
		        legend: {
		            layout: 'vertical',
		            align: 'right',
		            verticalAlign: 'middle',
		            borderWidth: 0
		        },
		        series: [{
		            name: 'Score',
		            data: obtainedScores
		        }],
		        scrollbar: {
		        	enabled: true,
		        	barBackgroundColor: 'gray',
		        	barBorderRadius: 7,
		        	barBorderWidth: 0,
		        	buttonBackgroundColor: 'gray',
		        	buttonBorderWidth: 0,
		        	buttonArrowColor: 'yellow',
		        	buttonBorderRadius: 7,
		        	rifleColor: 'yellow',
		        	trackBackgroundColor: 'white',
		        	trackBorderWidth: 1,
		        	trackBorderColor: 'silver',
		        	trackBorderRadius: 7
		        }
		    });
	}
	
	function getAllTestResults(url){
		$.ajax({
			url : url + "/showAllTestResults",
			type : 'GET',
			async : false,
			beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
	        		$('meta[name="_csrf_token"]').attr('content'))},
	        success : function(data){
	        	testResults = data;
	        	populateClassificationTable(data);
	        },
	        error : function(e){
	        	console.log(e);
	        }
		});
	}
	
	function populateClassificationTable(data){
		$('#testResults').find(".studentTestResult").remove();   
		
		var contor = 0;
		for (var i = 0; i< data.length; i++){
			contor++;
			$('#testResults').append('<tr class="studentTestResult">' +
					'<td>'+ contor +'</td>' +
					'<td>'+ data[i].firstName + '</td>' +
					'<td>'+ data[i].lastName + '</td>' +
					'<td>'+ data[i].email + '</td>' +
					'<td>'+ data[i].categoryname + '</td>' +
					'<td>'+ data[i].obtainedScore + '</td>' +
					"<td onclick=showChartModal("  + data[i].id + ","
													+ data[i].solvedSimpleQuestions + "," 
													+ data[i].solvedMediumQuestions + ","
													+ data[i].solvedDifficultQuestions
													+")><a class=see-graf-links>See chart</a>" +
					"</td>" +
				'</tr>');
		}
	}
	
	function closeChartModal(){
		$('#chartContainer').modal('hide');
	}
	
	function showChartModal(classif_id, 
							simpleQuestions,
							mediumQuestions,
							difficultQuestions){
		
		$('#chartContainer').modal('show');
		$('.modal-backdrop').removeClass('in');
		$('.modal-backdrop').addClass('out');
		
		$('#high-chart-container').highcharts({
		        chart: {
		            type: 'column',
		            margin: 80,
		            color : 'blue',
		            width : $( window ).width() * 0.45,
		            height : $( window ).height() * 0.40,
		            options3d: {
		                enabled: true,
		                alpha: 10,
		                beta: 25,
		                depth: 70
		            }
		        },
		        title: {
		            text: 'Test results',
		            align: "center",
		            floating: false,
		            margin: 10,
		            style: { "color": "steelblue", "fontSize": "19px" }
		        },
		        subtitle: {
		            text: 'Notice the number of correct answers for each category of difficulty',
		            style: { "color": "steelblue", "fontSize": "13px", "marginBottom" : "70px" }
		        },
		        plotOptions: {
		            column: {
		                depth: 25
		            }
		        },
		        xAxis: {
		            categories: ["Simple", "Medium", "Difficult"]
		        },
		        yAxis: {
		            title: {
		                text: null
		            }
		        },
		        series: [{
		            showInLegend: false,  
		            name: 'Questions',
		            data: [simpleQuestions, mediumQuestions, difficultQuestions]
		        }]
		    });
	}
	
	function drawQuestionContainer(questionOrderNumber,
			                       width, 
			                       columns,
			                       height,
			                       questionData,
			                       answer){
		
		var line = 0;
		var column = -1;
		var number = -1;
		while(number < questionOrderNumber){
			if(column < (columns-1)){
				column++;
	        }
	        else {
	        	column = 0;
	        	line++;
	        }
			number++;
	     }
		
		var startXCoordinate = width * column + 10;
		var startYCoordinate = height * line + 10;
		
		var question = {x: startXCoordinate,y:startYCoordinate,data:answer.name,answer_id:answer.id};
		
		questionData.push(question);
	}
	
	function correctAnswerOnSubmit(selectedAnswer){
		$("rect[data-id='" + selectedAnswer + "']").attr("fill","#66B666");
		$("rect[data-id='" + selectedAnswer + "']").on('mouseover',function (d){
														  $(this).attr("fill", "#66B666");
													  })
													  .on("mouseout", function(d){
															  $(this).attr("fill", "#66B666");
													  })
													  .on("click", function(d){
															  $(this).attr("fill", "#66B666");
													  });
	}
	
	function wrongAnswerOnSubmit(selectedAnswer,correctAnswer){
		$("rect[data-id='" + selectedAnswer + "']").attr("fill","#E60000");
		$("rect[data-id='" + selectedAnswer + "']").on('mouseover',function (d){
														  $(this).attr("fill", "#E60000");
													  })
													  .on("mouseout", function(d){
														  $(this).attr("fill", "#E60000");
													  })
													  .on("click", function(d){
														  $(this).attr("fill", "#E60000");
													  });
		$("rect[data-id='" + correctAnswer + "']").attr("fill","#66B666");
		$("rect[data-id='" + correctAnswer + "']").on('mouseover',function (d){
																  $(this).attr("fill", "#66B666");
															  })
															  .on("mouseout", function(d){
																	  $(this).attr("fill", "#66B666");
															  })
															  .on("click", function(d){
																  $(this).attr("fill", "#66B666");
															  });
	}

	function showLevelCompletedMessage(){
		$("#notificationDialog").show();
		
		setTimeout(function() {
			$('#notificationDialog').fadeOut('slow');
		}, 3000);
	}
	
	function getProfessorsMailList(url,obtained_score){
		var professorsMailList;
		
		$.ajax({
    		url : url + "/getAllProfessorsList",
    		type : 'GET',
    		async : false,
    		beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
            		$('meta[name="_csrf_token"]').attr('content'))},
            success : function(data){
            	professorsMailList = data;
            },
            error : function(e){
            	console.log(e);
            }
    	});
		//populate test result score element
		$('#test-result-score').val(obtained_score);
		
		// populate select element 
		for ( var contor = 0 ;contor < professorsMailList.length ; contor++){
			$('#email-container').append($("<option />")
					.val(professorsMailList[contor]).text(professorsMailList[contor]));
		}
	}
