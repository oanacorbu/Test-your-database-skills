// in functie de numarul de categorii, spatiul va fi divizat corespunzator

// layer-ul va fi impartit initial in 3 coloane si 3 linii, pe a doua linie,respectiv
// a doua coloana se va afla radacina grafului din care se poate porni testul

// graful este gandit ca avand 4 categorii dispuse in:
// - prima linie - a doua coloana,
// - a doua linie, prima si a treia coloana 
// - a treia linie, a doua coloana

// in cazul in care numarul de categorii creste,
// se vor completa si spatiile goale iar in cazul in care numarul de categorii
// este mai mare de 8, se va mari numarul de linii , linia din mijloc divizandu-se 
// in cate linii este necesar

$(document).ready(function() {
		var root;
		var graphData;
		var svgContainer;
		var numberOfCategories;

	    var selectedCategory = "";
	    var categories = [];
		
		var leftCoordinateX;
	    var topCoordinateY;
	    var rightCoordinateX;
	    var bottomCoordinateY;
	    
	    var line = -1;
	    var column = -1;
	    var columnWidth = 0;
	    var lineHeight = 0;
	    
	    // current position in the graph
	    var currentQuestionId = 1;
	    var currentQuestionIndex = 0;
	    var currentLevel = 1;
	    var firstTimeInApp = -1;
	    var svgPositionWhenEnteringInGraph = {};
	    var countSolvedQuestions = 0;
	    var progressBarContainer;
	    
	    // classification data
	    var obtained_score = 0;
	    var score = 0;
	    var solved_Difficult_Questions = 0;
	    var solved_Medium_Questions = 0;
	    var solved_Simple_Questions = 0;
	    var difficulty = "";
	    
		var selectedAnswer = -1;
		var selectedAnswerData = "";
	    var correctAnswer;
	    var categoryFinished;
	    
	    var numberOfQuestionsCopy = -1;
	    var numberOfLevelsCopy = -1;
	    
	    var initialQuestionId = -1;
	    var levelCompleted = false;
	    
	    var categoryNameSetInContainer = false;
	    var completeSituationOnTest = [];
	    
		initializeGraphContainer();
		openSettingsModal();
		takeGraphSettingsModalForm();
		cancelGraphSettingsModalForm();
		
		$('#submitQuestionForm').on('click',function(){
			
			if (selectedAnswer != -1){
				
				d3.select('#answers_container')
				  .selectAll('rect[class=answers-rect]')
				  .on('click',function (d,i){
					  $(this).attr("fill", "#FFFFD6");
				  })
				  .on('mouseover',function (d){
					  $(this).attr("fill", "#FFFFD6");
				  })
				  .on("mouseout", function(d){
					  $(this).attr("fill", "#FFFFD6");
				  });
				
				$('#submitQuestionForm').attr('disabled','disabled');
				
				completeSituationOnTest[completeSituationOnTest.length - 1].student_answer = selectedAnswerData;
				completeSituationOnTest[completeSituationOnTest.length - 1].correct_answer = correctAnswer.answer.name;
				
				if (selectedAnswer == correctAnswer.answer.id){
	        		obtained_score += score;
	        		switch (difficulty) {
	        			case "simple": solved_Simple_Questions;
	        					   	   break;
	        			case "medium": solved_Medium_Questions++;
	        						   break;
	        			case "difficult": solved_Difficult_Questions++;
	        				           break;	
	        		}
					correctAnswerOnSubmit(selectedAnswer);
				}
				else{
					wrongAnswerOnSubmit(selectedAnswer,correctAnswer.answer.id);
				}
				
				setTimeout(function(){
					if (levelCompleted == true){
						levelCompleted = false;
						$("line[class=connectionLine][data-level ='" + (currentLevel-1) + "'][data-category = '" + selectedCategory + "']").removeAttr("style");
						$("line[class=connectionLine][data-level ='" + (currentLevel-1) + "'][data-category = '" + selectedCategory + "']").attr("stroke-width",1).attr("stroke","#66B666");
						showLevelCompletedMessage();
					}
					
					$('#submitQuestionForm').removeAttr('disabled');
					$('#questionContainer').modal({
					    backdrop: true,
					    keyboard: true
					});
					$('.modal-backdrop').remove();
					$('#questionContainer').modal('hide');
					
					$('.pie_progress').asPieProgress('go', countSolvedQuestions);
					if (categoryFinished == true) {
						saveTestResults(root);
						getProfessorsMailList(root,obtained_score);
						$('#completedCategoryMessageContainer').modal('show');
					}
				},1500);
			}else{
				
			}
		});
		
		
		function initializeGraphContainer(){
			root = $('meta[name="root"]').attr('content');
			getGraphData(root);
			
			var zoom = d3.behavior
						 .zoom()
				         .scaleExtent([0.5, 2.5])
				         .on("zoom", zoomHandler);
			
			var svg = d3.select("#svg_container").append("svg")
							 .attr("id","svgggg")
						     .style("position","static")
						     .style("margin", 0)
						     .style("width",$(document).width()* 0.8 - 0.08 * $(document).width())
							 .style("height",$(document).height()* 0.80 - 0.04 * $(document).height())
					         .call(zoom);
			
			svgContainer = svg.append('g');
			
			var offset = $("#svg_container").offset();
			
			// populate array with categories names 
			numberOfCategories = graphData.length;
			
		    for (var categoryName in graphData){
		    	categories.push(graphData[categoryName].categoryName);
		    }
		    
		    // get coordinates for graph
		    leftCoordinateX = offset.left ;
		    topCoordinateY = offset.top;
		    rightCoordinateX = offset.left + $("#svgggg").width() - 0.05 * $("#svgggg").width();
		    bottomCoordinateY = offset.top + $("#svgggg").height() - 0.05 * $("#svgggg").height() ;
		 
		    $('#classificationTab a').click(function (e){
				$('#graphSettingsModalContainer').modal('hide');
				getAllTestResults(root);
				if (firstTimeInApp == 0)firstTimeInApp = -1;
			});
			$('#homeTab a').click(function (e){
				$('#graphSettingsModalContainer').modal('hide');
				if (firstTimeInApp == 0)firstTimeInApp = -1;
			});
			
			$('#submitCompletedCategoryForm').on('click', function(){
				$('#completedCategoryMessageContainer').modal('hide');
				sendMailToProfessorWithTestResults(root);
				reinitializeGraphState();
			});
		}
		
	function zoomHandler() { 
	    svgContainer.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
	}

	function populateGraph(){
		columnWidth = ((rightCoordinateX - leftCoordinateX)/3) * 0.9; // latimea & inaltimea unei categorii este de 0.75 
		lineHeight = ((bottomCoordinateY - topCoordinateY)/3) * 0.9;

		var dataForProgressBar = 0;
		
	    for ( var contor = 0; contor <graphData.length; contor++ ){
	    	if (graphData.length/7 == 1){
		    	
	    		var category = graphData[contor];
		    	
		    	switch(contor){
		    		case 0 : line = 0.05;
		    				 column = 0.6;
		    				 break;
		    		case 1 : column = 2;
		    				 break;
		    		case 2 : line = 1.1;
		    				 column = 0.2;
		    				 break;
		    		case 3 : column = 2.3;
		    				 break;
		    		case 4 : line = 2.2;
		    				 column = 0.2;
		    				 break;
		    		case 5 : column = 2.3;
		    				 break;
		    		case 6 : line = 2.4;
		    				 column = 1.25;
		    				 break;
		    	}
		    	
		    	
	    		if (category.categoryName == selectedCategory){
	    			svgPositionWhenEnteringInGraph.y = line * lineHeight; 
	    			svgPositionWhenEnteringInGraph.x = column * columnWidth;
	    			dataForProgressBar = computeDataForProgressBar(category);

				    currentQuestionId = category.categoryLevel[0].questionsDTO[0].id;
				    initialQuestionId = currentQuestionId;
	    		}	 
	    		categoryNameSetInContainer = false;
		    	drawCategorySpace(category, line, column);
	    	}
	    }
	    addProgressbarAndTimerToGraph(dataForProgressBar);
	}
	
	function computeDataForProgressBar(category){
		var nrOfQuestionsPerCategory = 0;
		
		$.each(category.categoryLevel, function( index, level ) {
			nrOfQuestionsPerCategory += level.questionsDTO.length;
			});
		
		return nrOfQuestionsPerCategory;
	}
	
	function addProgressbarAndTimerToGraph(dataForProgressBar){
		svgContainer.append("rect")
					.attr("width", columnWidth)
			        .attr("height", lineHeight)
					.attr("fill", "#FFFFC2")
					.attr("stroke-width", 2)
					.style("filter", "url(#drop-shadow-graph-container)")
					.attr("transform", function() { return "translate(" + 1.25 * columnWidth + "," + 1.23 * lineHeight + ")"; });
	
		$('.pie_progress').asPieProgress({
		    	min: 0,
		    	max: dataForProgressBar,
		    	goal: dataForProgressBar,
		    	size: dataForProgressBar,
		    	speed: 15, 
		    	speed: 15,
		    	barcolor: 'steelblue',
		    	barsize: '2',
		    	trackcolor: '#5E5E53',
		    	fillcolor: 'none',
		    	easing: 'ease',
		    	numberCallback: function(n) {
		    		var percentage = Math.round(this.getPercentage(n));
		    		return percentage + '%';
		    	},
		    });
		    
		$('.pie_progress').show();
		$('.pie_progress').asPieProgress('start');
	}
	
	function drawCategorySpace(category, line, column){
		
		var startXCoordinate = column * columnWidth;
		var startYCoordinate = line * lineHeight;
    	var categoryContainer = svgContainer;
    	var categoryLevels = category.categoryLevel;
    	var numberOfLevels = categoryLevels.length;

    	var defs = svgContainer.append("defs");
		var filter = defs.append("filter")
						 .attr("id", "drop-shadow-graph-container")
						 .attr("height", "150%");
		filter.append("feGaussianBlur")
			  .attr("in", "SourceAlpha")
			  .attr("stdDeviation", 5)
			  .attr("result", "blur");
		
		var feOffset = filter.append("feOffset")
							 .attr("in", "blur")
							 .attr("dx", 5)
							 .attr("dy", 5)
							 .attr("result", "offsetBlur");
		
		var feMerge = filter.append("feMerge");
		feMerge.append("feMergeNode")
			   .append("in", "offsetBlur")
		feMerge.append("feMergeNode")
			   .attr("in", "SourceGraphic");
		
    	categoryContainer = svgContainer.append("rect")
										.attr("width", columnWidth)
								        .attr("height", lineHeight)
										.attr("fill", "#FFFFC2")
										.attr("stroke-width", 2)
										.style("filter", "url(#drop-shadow-graph-container)")
										.attr("transform", function() { return "translate(" + startXCoordinate + "," + startYCoordinate + ")"; })
    	
       
    	// calculate the matrix schema of a category  
    	var numberOfLines = Math.floor(Math.sqrt(categoryLevels.length));
		var numberOfColumns = Math.ceil(Math.sqrt(categoryLevels.length));
		
		if (categoryLevels.length > (numberOfLines * numberOfColumns)){
			numberOfLines++;
		}
    	
		var firstQuestionFromPreviousLevel = {};
    	for ( var levelNumber = 0; levelNumber < categoryLevels.length; levelNumber++){
    		
    		// retrieve current category level`s questions
    		var levelQuestions = categoryLevels[levelNumber].questionsDTO;
    		// draw a category section
    		firstQuestionFromPreviousLevel = drawLevelQuestions(
    				numberOfLines, 
    				numberOfColumns, 
    				levelQuestions, 
    				startXCoordinate, startYCoordinate, 
    				levelNumber, categoryLevels.length,
    				firstQuestionFromPreviousLevel,
    				category.categoryName);
    	}
	} 
	
	function calculateRotation(numberOfColumns, column, orientation){
		 var rotate = 0;
	        
	     if (numberOfColumns % 2 == 1){
	        if (orientation == "left"){
	        	if (column % 2 == 0){
	        		if( column != 0){
	        			rotate = 180;
	        		}
	        	}
	        	else {
	        		rotate = 90;
	        	}
	        }
	        else {
	        	if (column % 2 == 0){
	        		if( column != 0){
	        			rotate = 180;
	        		}
	        		else{
	        			rotate = 0;
	        		}
	        	}
	        	else {
	        		rotate = 270;
	        	}
	        }
	     }
	     else{
	    	 if (orientation == "left"){
		        if (column % 2 != 0){
		        	rotate = 180;
		       	}
		     }
	    	 else{
	    		if (column % 2 != 0){
	    			rotate = 180;
			    }
	    	 }
	     }
	     
	     return rotate;
	}
	
	function drawLevelQuestions( numberOfLines, 
								 numberOfColumns,
								 questions, 
								 categoryXCoordinate,
							     categoryYCoordinate,
								 levelNumber, 
							     numberOfLevels,
							     firstQuestionFromPreviousLevel,
							     categoryName){
		
		var radius;
		var circleRadius;
        var width;
        var height;
        var rad = Math.PI/180;
        var interval = 360/questions.length;
        var lineData = [];
        var lastXElement = [];
        var lastYElement = [];
        var numberOfQuestions = questions.length; 
        var firstCircle;
        var firstCircleX,firstCircleY;
        var orientation = "left";
        
        // find out where is this level placed in the category schema
        
        var line = 0;
        var column = -1;
        var level = -1;
        
        while(level < levelNumber){
        	if(column < (numberOfColumns-1)){
        		column++;
        	}
        	else {
        		column = 0;
        		if (orientation == "left"){
        			orientation = "right";
        		}
        		else{
        			orientation = "left";
        		}
        		line++;
        	}
        	level++;
        }
        
        if (orientation == "right"){
        	column = (numberOfColumns - 1 ) - column; 
        }
        
        if (questions.length <= 8 ){
            radius = parseInt(lineHeight,10)/numberOfLines *0.5;
            circleRadius = parseInt(lineHeight,10)/100 * 2.8;
        }else{
            radius = parseInt(lineHeight,10)/ numberOfLines * 0.6;
            circleRadius = parseInt(lineHeight,10)/100 * 2.9;
        }
        
        width = radius * 3;
        height = width;
        
        // find out level coordinates in category space
        
        var startXCoordinate = (columnWidth/numberOfColumns) * column + categoryXCoordinate;
        var startYCoordinate = (lineHeight/numberOfLines) * line + categoryYCoordinate;
        
        var rotate = calculateRotation(numberOfColumns, column, orientation);
       
        var categoryContainer = svgContainer.append('g').attr("transform","translate(" + startXCoordinate +"," + startYCoordinate+")")
        var levelContainer = categoryContainer.append('g')
        									  .attr('data-level-id',levelNumber + 1)
        									  .attr('data-category', categoryName)
        									  .attr("transform", "translate(" + radius + "," + radius + ")rotate(" + rotate +")");
        
        if ( categoryNameSetInContainer == false){
        	var categoryText = categoryContainer.append("text")
												 .attr("x", columnWidth/2)
												 .attr("y", lineHeight - 3)
										    	 .attr("font-family", "Arial, Helvetica, sans-serif")
										    	 .attr("font-size", "9.5px")
										    	 .attr("fill", "#79796D")
										    	 .style("font-weight","bold")
										    	 .text(categoryName)
										    	 .style("text-anchor", "middle")
										    	 .style("position", "absolute");
        	categoryNameSetInContainer = true;
        }

        
        // create lines between circles
        for ( var i = 0; i < questions.length; i++ ){
            var line = {
                 x:(((width/2) - radius) * Math.cos((interval * i) * Math.PI/180)),
                 y:(((width/2) - radius) * Math.sin((interval * i) * Math.PI/180))
            };
            lineData.push(line);
        }
        
        var linesContainer = levelContainer.selectAll("line")
								      .data(lineData)
								      .enter()
								      .append("line");
        
        var line = linesContainer.attr("x1", function(d){ 
							     	lastXElement.push(d.x); 
							        return d.x; 
							      })
							     .attr("y1", function(d){ 
							    	 lastYElement.push(d.y); 
							    	 return d.y; 
							     	})
							     .attr("x2", function(d,i){ 
							    	 if ( i == (questions.length - 1) ) 
							    		 return lastXElement[0];
							         else 
							        	 return lastXElement[i + 1]; 
							      })
							     .attr("y2", function(d,i){ 
							    	 if ( i == (questions.length - 1) ) 
							    		 return lastYElement[0];
							         else 
							        	 return lastYElement[i + 1];
							      })
							     .style("stroke", "black")
							     .style("class","lines")
							     .attr("stroke-width", 2)
							     .attr("fill", function(d,i){ 
							    	 if (categoryName === selectedCategory){
							    		 $(this).attr("data-category",selectedCategory);
								    	 $(this).attr("data-index",i);
								    	 $(this).attr("data-level",levelNumber);
							    	 }
							    	 return "none";
							      })
							     .attr("class","groupingLines");
        
        var circlesContainer = levelContainer.selectAll('g')
									         .data(questions)
									         .enter()
									         .append('circle');

        var circle = circlesContainer.attr('fill', 'steelblue')
							         .attr('r', function(d,i){
							        	 if (d.id == initialQuestionId ){
								        	 $(this).attr('fill','#66B666');
								        	 return circleRadius; 
							        	 }
							        	 else return circleRadius;
							          })
							         .style('class','circles')
							         .attr('id',function (d,i){
							        	 return d.id;
							         })
							         .attr('data-level-index',function(d,i){
							        	 return i;
							         })
							         .on("click", function(d){
							        	 var circleIndex = d3.select(this).attr('data-level-index');
							        	 if(currentQuestionIndex == circleIndex && currentQuestionId == d.id){
							        		 
							        		 score = d.score;
							        		 difficulty = d.difficulty;
							        		 $(this).attr('fill','#66B666');
							        		 
							        		 completeSituationOnTest.push({
							        			 question_name : d.name,
							        			 question_score : d.score,
							        			 student_answer : "",
							        			 correct_answer : ""
							        			 });
							        		 
							        		 $("line[class=groupingLines][data-level='" +(currentLevel - 1) + "'][data-category='" + selectedCategory + "'][data-index='" + currentQuestionIndex + "']").removeAttr("style");
							        		 $("line[class=groupingLines][data-level='" +(currentLevel - 1) + "'][data-category='" + selectedCategory + "'][data-index='" + currentQuestionIndex + "']").attr("stroke-width",1).attr("stroke","#66B666");
							        		
							        		 showQuestionModal(d,numberOfQuestions,numberOfLevels);
							        	 }else{
							        		 console.log("nu respecta flow-ul");
							        	 }
							        	 
							         })
							         .attr('transform', function (d, i) {
							        	 var line = { 
							        			 x:(((width/2) - radius) * Math.cos((interval * i) * Math.PI/180)),
							        			 y:(((width/2) - radius) * Math.sin((interval * i) * Math.PI/180))
							             }; 
							        	 
							        	 //connect to previous level
							             if (i == 0 ){
							            	 
							            	 firstCircle = this.getScreenCTM();
							            	 firstCircleX = (firstCircle.a * line.x) + (firstCircle.c * line.y) + firstCircle.e ;
							            	 firstCircleY = (firstCircle.b * line.x) + (firstCircle.d * line.y) + firstCircle.f ;
							            	 
								             if(!jQuery.isEmptyObject(firstQuestionFromPreviousLevel)){
								            	 var connectionLine = svgContainer.append('line')
																	 		      .attr({
																	 		    	  x1: firstQuestionFromPreviousLevel.x,
																	 		    	  y1: firstQuestionFromPreviousLevel.y,
																	 		          x2: firstCircleX,
																	 		          y2: firstCircleY,
																	 		          stroke: 'steelblue'
																	 		      })
																	 		      .style("stroke-dasharray", ("3, 3"));
								                 if (categoryName == selectedCategory){
								                	 connectionLine.attr("data-category", selectedCategory)
									 		         			   .attr("data-level", levelNumber)
									 		         			   .attr("class","connectionLine");
								                 }
								             }
							             }
							        	 lineData.push(line);
							             return "translate(" + line.x + "," + line.y + ")";
							          });
        $('circle').tipsy({ 
            gravity: 'w', 
            html: true, 

            title: function() {
              var d = this.__data__;
              return d.description; 
            }
        });
        
        return {x:firstCircleX, y:firstCircleY};
	}
	
	function moveToNextQuestion(numberOfQuestions,numberOfLevels){
		if (currentQuestionIndex >= (numberOfQuestions - 1) ){
			if(currentLevel < numberOfLevels){
				currentQuestionIndex = 0;
				currentLevel++;
				currentQuestionId++;
				levelCompleted = true;
			}
		}else{
			currentQuestionId++;
			currentQuestionIndex++;
		}
		
		countSolvedQuestions++;
	}
		
	function reinitializeGraphState(){
		currentQuestionId = 0;
	    currentQuestionIndex = 0;
	    currentLevel = 1;
	    countSolvedQuestions = 0;
	    obtained_score = 0;
	    selectedCategory = "";
	    
	    solved_Difficult_Questions = 0;
	    solved_Medium_Questions = 0;
	    solved_Simple_Questions = 0;
	    
	    selectedAnswerData = "";
	    completeSituationOnTest = [];
	    
	    initialQuestionId = -1;
	    
	    categories = [];
	    line = -1;
	    column = -1;
	    columnWidth = 0;
	    lineHeight = 0;
	    
	    svgPositionWhenEnteringInGraph = {};
	    score = 0;
	    difficulty = "";
	    selectedAnswer = -1;
	    
	    numberOfQuestionsCopy = -1;
	    numberOfLevelsCopy = -1;
	    levelCompleted = false;
	    categoryNameSetInContainer = false;
	    
		$('.pie_progress').asPieProgress('finish');
		$('.pie_progress').asPieProgress('reset');
	    $('.pie_progress').hide();
	    
	    $('#svg_container').empty();
	    $('#svg_container').hide();
	    initializeGraphContainer();
	    
	    /* reinitialize settings */
	    firstTimeInApp = -1;
	    $('#categoriesSvgContainer').empty();
	    drawCategoriesInGraphSettingsModal();
		$('#graphSettingsModalContainer').modal('show');
		
		positionateSettingsModal();
		
		$('#submitGraphSettingsModalForm').attr('disabled','disabled');
	}
	
	function showQuestionModal(d,numberOfQuestions, numberOfLevels){
		
		$('#questionContainer').modal({
		    backdrop: 'static',
		    keyboard: false
		});
		
		selectedAnswer = -1;
		selectedAnswerData = "";
		correctAnswer = populateQuestionModalWithData(d,root);
		
		categoryFinished = false;
		if ((currentQuestionIndex == (numberOfQuestions-1)) && (currentLevel == numberOfLevels)){
			categoryFinished = true;
		}
		
		numberOfQuestionsCopy = numberOfQuestions;
		numberOfLevelsCopy = numberOfLevels;
		
		moveToNextQuestion(numberOfQuestions,numberOfLevels);
	}

	function saveTestResults(url){
		var data = {
			categoryname : selectedCategory,
			obtainedScore : obtained_score,
			solvedDifficultQuestions : solved_Difficult_Questions,
			solvedMediumQuestions : solved_Medium_Questions,
			solvedSimpleQuestions : solved_Simple_Questions
		};
		
		$.ajax({
    		url : url + "/saveResults",
    		type : 'POST',
    		data : data,
    		async : false,
    		beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
            		$('meta[name="_csrf_token"]').attr('content'))},
            success : function(){
            },
            error : function(e){
            	console.log(e);
            }
    	});
	}
	
	// load graph data
	function getGraphData(url){
    	$.ajax({
    		url : url + "/retrieveCategoriesData",
    		type : 'GET',
    		async : false,
    		beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
            		$('meta[name="_csrf_token"]').attr('content'))},
            success : function(data){
            	graphData = data;
            },
            error : function(e){
            	console.log(e);
            }
    	});
    }
	
	function openSettingsModal(){
		$('#testTab a').click(function (e) {
			if (firstTimeInApp == -1){
				firstTimeInApp = 0;
				drawCategoriesInGraphSettingsModal();
				$('#graphSettingsModalContainer').modal('show');
				
				positionateSettingsModal();
				
				$('#submitGraphSettingsModalForm').attr('disabled','disabled');
			}
			else{
				$('.pie_progress').show();
			}
		});
		$('#classificationTab a').on("click",function(){
			$('.pie_progress').hide();
		});
		$('#homeTab a').on("click",function(){
			$('.pie_progress').hide();
		});
	}
	
	function takeGraphSettingsModalForm(){
		$('#submitGraphSettingsModalForm').on('click',function(){
			if (selectedCategory !== ""){
				$('#graphSettingsModalContainer').modal({
					backdrop : true,
					keyboard : true,
				});
				firstTimeInApp = -2;
	
			    populateGraph();
			    
				$('#svg_container').show();
				$('#graphSettingsModalContainer').modal('hide');
			}
			else{
				$('#settingsError').show();
			}
		});
	}
	
	function cancelGraphSettingsModalForm(){
		$('#cancelGraphSettingsModalForm').on('click',function(){
			$('#graphSettingsModalContainer').modal('hide');
			firstTimeInApp = -1;
		});
	}
	
	function positionateSettingsModal(){
		var width = parseInt($('#tabsContainer').css("width"),10) - (parseInt($('#tabsContainer').css("width"),10) - parseInt($('#svg_container').css("width"),10));
		var height = parseInt($('#tabsContainer').css("height"),10) - (parseInt($('#tabsContainer').css("height"),10) - parseInt($('#svg_container').css("height"),10));
		var marginLeft = parseInt($('#tabsContainer').css("margin-left"),10) + parseInt($('#svg_container').css("margin-left"),10);
		var marginRight = parseInt($('#tabsContainer').css("margin-right"),10) + parseInt($('#svg_container').css("margin-right"),10);
		var marginTop =  parseInt($('#tabsContainer').css("margin-top"),10) + parseInt($('#svg_container').css("margin-top"),10) + parseInt($('#headerHomePage').css("height"),10);
		
		$('.modal-backdrop').css({
			"width" : width,
			"height" : height,
			"margin-left" : marginLeft,
			"margin-right" : marginRight,
			"margin-top" : marginTop,
			"opacity" : 0
		});
	}
	
	function drawCategoriesInGraphSettingsModal(){
		$('#categoriesSvgContainer').empty();
		var containerWidth = ($('#graphSettingsModalContainer').width() * (9/10))/4;
		var containerHeight = ($('#graphSettingsModalContainer').height() * (7/10))/4;
		
		var widthRadius = (containerWidth) * 0.65;
		
		var categoriesData = [
		    {x : (widthRadius), y: containerHeight * 0.5},
		    {x : (widthRadius) + containerWidth * 2, y: containerHeight * 0.5},
		    {x : (widthRadius) + containerWidth, y: containerHeight * 0.25},
		    {x : (widthRadius), y: containerHeight * 2.75},
		    {x : (widthRadius) + containerWidth * 2, y: containerHeight * 2.75},
		    {x : (widthRadius) + containerWidth, y: containerHeight * 3},
		    {x : (widthRadius) + containerWidth, y: containerHeight * 1.65}
		];
		
		for (var contor in categoriesData){
			categoriesData[contor]["categoryName"] = categories[contor];
		}
		
		var svg=d3.select("#categoriesSvgContainer")
        		  .append("svg")
        		  .attr("width","100%")
        		  .attr("height","100%");
		
		var defs = svg.append("defs");
		var filter = defs.append("filter")
						 .attr("id", "drop-shadow")
						 .attr("height", "150%");
		filter.append("feGaussianBlur")
			  .attr("in", "SourceAlpha")
			  .attr("stdDeviation", 5)
			  .attr("result", "blur");
		
		var feOffset = filter.append("feOffset")
							 .attr("in", "blur")
							 .attr("dx", 5)
							 .attr("dy", 5)
							 .attr("result", "offsetBlur");
		
		var feMerge = filter.append("feMerge");
		feMerge.append("feMergeNode")
			   .append("in", "offsetBlur")
		feMerge.append("feMergeNode")
			   .attr("in", "SourceGraphic");
		
		var item = svg.selectAll("rect")
	    			  .data(categoriesData)
	    			  .enter().append("rect")
					  .attr("width", 170)
					  .attr("height", 100)
					  .attr("fill", "steelblue")
					  .attr("stroke-width", 2)
					  .attr("class","settings-rect")
					  .style("filter", "url(#drop-shadow)")
					  .attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; })
					  .on('click',function (d,i){
						  d3.selectAll(".settings-rect").attr("fill", "steelblue");
						  $(this).attr("fill", "#C28851");
						  selectedCategory = d.categoryName;
						  $('#submitGraphSettingsModalForm').removeAttr('disabled');
					  })
					  .on('mouseover',function (d){
						  $(this).attr("fill", "#C28851");
					  })
					  .on("mouseout", function(d){
						  if (!(selectedCategory == d.categoryName)){
							  $(this).attr("fill", "steelblue");
						  }
					  });
		 var addText = svg.selectAll("text")
		 				  .data(categoriesData)
		 				  .enter()
		 				  .append("text");
		
		 var textElements = addText.attr("x", function(d, i){
						             return d.x + 90;
						         	})
						         	.attr("y", function(d, i){
						         		return d.y + 50;
						         	})
						         	.attr("font-family", "Arial, Helvetica, sans-serif")
						         	.attr("font-size", "17px")
						         	.attr("fill", "white")
						         	.text(function(d, i){return d.categoryName;})
						         	.style("text-anchor", "middle")
		 							.style("position", "absolute");
	}
	
	function populateQuestionModalWithData(d, url){
		
		$('#question-modal-header').empty();
		$('#questionAnswers').empty();
		
		$('#question-modal-header').append('<h4 id="question-header-input">' + d.name + '</h4>');
		if ( d.image_relative_path != null){
			$('#question-modal-header').append('<img id="img-question-modal-header" src=' + root + "/resources/images/" + d.image_relative_path +'/>');
		}
		
		$('#submitQuestionForm').attr('disabled','disabled');
		
		var questionAnswers = {};
		var correctAnswer = {};
		
		// get questions`s answers
		$.ajax({
			url : url + "/retrieveQuestionAnswers",
			type : 'GET',
			data : {question_id : d.id},
			async : false,
			beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
	        		$('meta[name="_csrf_token"]').attr('content'))},
	        success : function(data){
	        	questionAnswers = data;
	        },
	        error : function(e){
	        	console.log(e);
	        }
		});
		
		// get question`s correct answer
		$.ajax({
			url : url + "/retrieveQuestionCorrectAnswer",
			type : 'GET',
			data : {question_id : d.id},
			async : false,
			beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
	        		$('meta[name="_csrf_token"]').attr('content'))},
	        success : function(data){
	        	correctAnswer = data;
	        },
	        error : function(e){
	        	console.log(e);
	        }
		});
		
		drawQuestionsAnswers(questionAnswers);

		$('#questionContainer').modal('show');
		
		return correctAnswer;
	}
	
	function drawQuestionsAnswers(answers){
		
		var answersContainer = d3.select("#questionAnswers")
								 .append("svg")
								 .attr("id","answers_container")
							     .style("position","static")
							     .style("margin", 0)
							     .style("margin-left", -10)
							     .style("width", "100%")
							     .style("height", "100%");
		
		var defs = answersContainer.append("defs");
		var filter = defs.append("filter")
						 .attr("id", "drop-shadow-questions-answers")
						 .attr("height", "150%");
		filter.append("feGaussianBlur")
			  .attr("in", "SourceAlpha")
			  .attr("stdDeviation", 5)
			  .attr("result", "blur");
		
		var feOffset = filter.append("feOffset")
							 .attr("in", "blur")
							 .attr("dx", 5)
							 .attr("dy", 5)
							 .attr("result", "offsetBlur");
		
		var feMerge = filter.append("feMerge");
		feMerge.append("feMergeNode")
			   .append("in", "offsetBlur")
		feMerge.append("feMergeNode")
			   .attr("in", "SourceGraphic");
		
		var lines = Math.ceil(Math.sqrt(answers.length));
		var columns = Math.floor(Math.sqrt(answers.length));
		
		if ((lines * columns) < answers.length){
			columns++;
		}
		
		var width = (530)/columns;
		var height = (150)/lines;

		var questionData = [];
		for (var contor = 0; contor < answers.length ; contor++){
			drawQuestionContainer(contor, width,columns,height,questionData, answers[contor]);
		}
		
		answersContainer.selectAll("rect")
						  .data(questionData)
						  .enter().append("rect")
						  .attr("width", width -25)
						  .attr("height", height -20)
						  .attr("fill", "#FFFFD6")
						  .attr("stroke-width", 2)
						  .attr("class","answers-rect")
						  .style("filter", "url(#drop-shadow-questions-answers)")
						  .attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; })
						  .attr("data-id",function(d){
							  return d.answer_id;
						  })
						  .on('click',function (d,i){
							  $('#submitQuestionForm').removeAttr('disabled');
							  d3.selectAll(".answers-rect").attr("fill", "#FFFFD6");
							  $(this).attr("fill", "steelblue");
							  selectedAnswer = d.answer_id;
							  selectedAnswerData = d.data;
						  })
						  .on('mouseover',function (d){
							  $(this).attr("fill", "steelblue");
						  })
						  .on("mouseout", function(d){
							  if (!(selectedAnswer == d.answer_id)){
								  $(this).attr("fill", "#FFFFD6");
							  }
						  });
						
		 var addAnswerText = answersContainer.selectAll("text")
						  					 .data(questionData)
						  					 .enter()
						  					 .append("text");

		 var textElements = addAnswerText.attr("x", function(d, i){
							              	return d.x + width/2 - 10;
							         	  })
							         	 .attr("y", function(d, i){
							         		return d.y + height/2 - 5;
							         	  })
							         	 .attr("font-family", "Arial, Helvetica, sans-serif")
							         	 .attr("font-size", "14px")
							         	 .attr("fill", "black")
							         	 .text(function(d, i){return d.data;})
							         	 .style("text-anchor", "middle")
							         	 .style("position", "absolute");
	}
	
	function sendMailToProfessorWithTestResults(url){
		var data = {
				categoryname : selectedCategory,
				obtainedScore : obtained_score,
				solvedDifficultQuestions : solved_Difficult_Questions,
				solvedMediumQuestions : solved_Medium_Questions,
				solvedSimpleQuestions : solved_Simple_Questions,
				email : $( "#email-container option:selected" ).text(),
				completeSituationOnTest : completeSituationOnTest
			};
		
		$.ajax({
	    	url : url + "/sendEmailWithTestResults",
	    	type : 'POST',
	    	data : data,
	    	async : false,
	    	beforeSend : function(xhr){xhr.setRequestHeader('X-CSRF-Token',
	           	$('meta[name="_csrf_token"]').attr('content'))},
	        success : function(){},
	        error : function(e){
	            console.log(e);
	        }
	    });

		$('#email-container').empty();
	}
});